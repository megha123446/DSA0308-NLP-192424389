"""
FastAPI Asynchronous Web Server (Enhanced Dual-Engine)
Provides Real-Time WebSocket streaming, REST API endpoints,
Document File Parsing (.txt, .docx, .pdf, .md),
Document Export (.docx, .txt, .md), and static file hosting.
"""

import os
import io
import json
import time
from typing import Dict, Any, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel

import docx
import pypdf

from core.pipeline import GrammarSystemPipeline

app = FastAPI(
    title="Intelligent Grammar Error Detection & Correction System",
    description="A Production-Grade Capstone System combining Rule-Based and Transformer Algorithms for Real-Time Grammar Correction.",
    version="2.0.0"
)

# Enable CORS for local cross-origin development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize pipeline instance
pipeline = GrammarSystemPipeline()

# Curated benchmark sample datasets showcasing complex grammar rules and neural transformer attention
SAMPLE_DATASETS = [
    {
        "id": "sample-complex",
        "title": "Complex_Grammar_Master.txt (All Rules & Transformer)",
        "description": "Tests intervening SVA, counterfactual conditionals, pronoun cases, double negatives, and neural collocations.",
        "text": "The box of chocolates are on the table, and everyone have arrived. If I would have known about the test, I would have prepared. Between you and I, he don't have no experience, but was interested about learning."
    },
    {
        "id": "sample-essay",
        "title": "Essay_Draft.txt (GrammarGenius Benchmark)",
        "description": "Real-world student essay with tense shifts, agreement, and punctuation errors.",
        "text": "She go to school yesterday and her friend was waiting for her at the gate. They was very happy to see each other. The weather was good so they played in the park."
    },
    {
        "id": "sample-sva-complex",
        "title": "Intervening_SVA_and_Pronouns.docx",
        "description": "Tests complex intervening prepositional phrases, indefinite pronouns, and distributive heads.",
        "text": "The quality of these new software products are exceptional. Each of the students have submitted their thesis. Neither the manager nor the employees was aware of the change."
    },
    {
        "id": "sample-academic",
        "title": "Academic_Research_Abstract.pdf",
        "description": "Academic paragraph testing phonetic article exceptions, quantifiers, and style redundancies.",
        "text": "This paper present an unique opportunity to conduct a interview. Researchers collected much books for less people. The authors revert back to past history and discuss about the end result."
    },
    {
        "id": "sample-transformer",
        "title": "Neural_Collocations_and_Fluency.txt",
        "description": "Highlights idiomatic prepositions, Latin comparatives, and natural phrasing evaluated by neural attention.",
        "text": "The committee will discuss about the proposal tomorrow. In the other hand, researchers must do a decision. This approach is superior than existing methods, and students look forward to see the outcome."
    },
    {
        "id": "sample-tense",
        "title": "Perfect_Aspect_and_Auxiliaries.txt",
        "description": "Tests irregular past participles, modal verbs, and negative auxiliary verbs.",
        "text": "She has went to the conference and have saw the keynote speech. He did not knew the answer, but will went home early because its raining."
    }
]


class TextRequest(BaseModel):
    text: str


class ExportRequest(BaseModel):
    text: str
    corrected_text: str
    format: Optional[str] = "markdown"  # "markdown", "json", "docx", "txt"
    filename: Optional[str] = "grammar_report"


class DownloadDocRequest(BaseModel):
    text: str
    corrected_text: str
    format: Optional[str] = "docx"  # "docx", "txt"
    filename: Optional[str] = "corrected_document"


@app.post("/api/analyze")
async def analyze_text(payload: TextRequest):
    """Executes full 4-module pipeline and returns detailed diagnostics."""
    try:
        results = pipeline.analyze(payload.text)
        return JSONResponse(content=results)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    """
    Accepts real-time document upload (.txt, .docx, .pdf, .md).
    Extracts text, executes the 4-module grammar pipeline, and returns full analysis.
    """
    try:
        filename = file.filename or "uploaded_file.txt"
        contents = await file.read()
        file_size_kb = round(len(contents) / 1024, 1)
        ext = os.path.splitext(filename)[1].lower()

        extracted_text = ""

        if ext in [".docx", ".doc"]:
            # Parse DOCX using python-docx
            doc_stream = io.BytesIO(contents)
            doc = docx.Document(doc_stream)
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            extracted_text = "\n\n".join(paragraphs)

        elif ext == ".pdf":
            # Parse PDF using pypdf
            pdf_stream = io.BytesIO(contents)
            reader = pypdf.PdfReader(pdf_stream)
            pages_text = []
            for page in reader.pages:
                txt = page.extract_text()
                if txt:
                    pages_text.append(txt.strip())
            extracted_text = "\n\n".join(pages_text)

        elif ext in [".pptx", ".ppt"]:
            # Parse PPTX using python-pptx
            import pptx
            prs_stream = io.BytesIO(contents)
            prs = pptx.Presentation(prs_stream)
            slide_texts = []
            for slide in prs.slides:
                for shape in slide.shapes:
                    if shape.has_text_frame:
                        for paragraph in shape.text_frame.paragraphs:
                            p_txt = "".join([r.text for r in paragraph.runs if r.text])
                            if p_txt.strip():
                                slide_texts.append(p_txt.strip())
            extracted_text = "\n\n".join(slide_texts)

        else:
            # Plain text (.txt, .md, .rtf, .csv)
            try:
                extracted_text = contents.decode("utf-8")
            except UnicodeDecodeError:
                extracted_text = contents.decode("latin-1", errors="replace")

        if not extracted_text.strip():
            extracted_text = "Empty document uploaded. Please upload a file with readable text content."

        # Run complete hybrid pipeline
        analysis = pipeline.analyze(extracted_text)

        return JSONResponse(content={
            "filename": filename,
            "file_size_kb": file_size_kb,
            "format": ext,
            "extracted_text": extracted_text,
            "analysis": analysis
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to parse file: {str(e)}")


@app.post("/api/download-corrected")
async def download_corrected_document(payload: DownloadDocRequest):
    """
    Generates and returns a downloadable .docx or .txt file containing the corrected text.
    """
    try:
        format_type = (payload.format or "docx").lower()
        base_name = os.path.splitext(payload.filename or "corrected_document")[0]

        if format_type == "docx":
            doc = docx.Document()
            doc.add_heading("GrammarGenius - Corrected Document", 0)
            doc.add_paragraph("Generated by Intelligent Grammar Error Detection & Correction System")
            doc.add_paragraph(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
            doc.add_heading("Corrected Text", level=1)

            for p in payload.corrected_text.split("\n\n"):
                if p.strip():
                    doc.add_paragraph(p.strip())

            buf = io.BytesIO()
            doc.save(buf)
            buf.seek(0)

            return StreamingResponse(
                buf,
                media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                headers={"Content-Disposition": f"attachment; filename={base_name}_corrected.docx"}
            )

        else:
            # Plain text (.txt)
            content = f"GRAMMARGENIUS CORRECTED DOCUMENT\nGenerated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n{payload.corrected_text}"
            buf = io.BytesIO(content.encode("utf-8"))
            buf.seek(0)
            return StreamingResponse(
                buf,
                media_type="text/plain",
                headers={"Content-Disposition": f"attachment; filename={base_name}_corrected.txt"}
            )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/samples")
async def get_sample_texts():
    """Returns curated benchmark text samples."""
    return JSONResponse(content=SAMPLE_DATASETS)


@app.get("/api/health")
async def health_check():
    """System health and status monitor."""
    return JSONResponse(content={
        "status": "online",
        "system": "Intelligent Grammar Error Detection and Correction",
        "modules": [
            "Module 1: Text Input & Preprocessing",
            "Module 2: Rule-Based Grammar Error Detection",
            "Module 3: Transformer-Based Grammar Correction",
            "Module 4: Hybrid Integration & Error Resolution"
        ],
        "timestamp": time.time()
    })


@app.post("/api/export")
async def export_report(payload: ExportRequest):
    """Generates a downloadable formal Capstone evaluation report."""
    results = pipeline.analyze(payload.text)
    metrics = results["metrics"]
    hybrid = results["module4_hybrid"]
    rules = results["module2_rule_engine"]
    trf = results["module3_transformer"]

    if payload.format == "json":
        return JSONResponse(content=results)

    # Markdown format report
    report_md = f"""# Capstone Project Evaluation Report
## Intelligent System for Automatic Grammar Error Detection & Correction
**Architecture:** Hybrid Rule-Based & Neural Transformer Multi-Head Self-Attention

### 1. Executive Telemetry
- **Grammar Health Score:** {metrics['grammar_health_score']} / 100
- **Total Violations Detected:** {metrics['total_errors_detected']}
- **Error Density:** {metrics['error_density_per_100_words']} errors per 100 words
- **Flesch Reading Ease:** {metrics['readability']['flesch_reading_ease']} ({metrics['readability']['reading_difficulty']})
- **Flesch-Kincaid Grade Level:** {metrics['readability']['flesch_grade_level']}
- **Pipeline Latency:** {metrics['latencies_ms']['total_pipeline']} ms

### 2. Comparative Text
#### Original Text:
> {payload.text}

#### Corrected Text (Hybrid Arbiter Resolution):
> {hybrid['final_corrected_text']}

### 3. Module Breakdown
- **Module 1 (Preprocessing):** {results['module1_preprocessing']['stats']['word_count']} words, {results['module1_preprocessing']['stats']['sentence_count']} sentences.
- **Module 2 (Rule Engine):** {rules['violations_count']} violations flagged.
- **Module 3 (Transformer):** {len(trf['suggestions'])} suggestions (Fluency: {trf['fluency_score']}%, Perplexity: {trf['perplexity_estimate']}).
- **Module 4 (Hybrid Arbiter):**
  - Rule Contribution: {hybrid['metrics']['rule_contribution_pct']}%
  - Transformer Contribution: {hybrid['metrics']['transformer_contribution_pct']}%
  - Agreement Rate: {hybrid['metrics']['agreement_rate_pct']}%
  - Average Ensemble Confidence: {hybrid['metrics']['average_ensemble_confidence']}

### 4. Detailed Resolved Edits
| Edit ID | Offending Text | Corrected Text | Source | Category | Explanation |
|---|---|---|---|---|---|
"""
    for e in hybrid["resolved_edits"]:
        report_md += f"| {e['edit_id']} | `{e['original']}` | **`{e['replacement']}`** | {e['source']} | {e['category']} | {e['explanation']} |\n"

    return JSONResponse(content={"markdown": report_md, "filename": "grammar_system_report.md"})


@app.websocket("/ws/grammar")
async def websocket_grammar_endpoint(websocket: WebSocket):
    """
    High-performance real-time WebSocket connection.
    Streams back multi-module outputs on each keystroke in under 30ms.
    """
    await websocket.accept()
    try:
        while True:
            raw_message = await websocket.receive_text()
            try:
                data = json.loads(raw_message)
                text = data.get("text", "")
            except json.JSONDecodeError:
                text = raw_message

            # Process through 4-stage pipeline
            analysis = pipeline.analyze(text)
            
            # Send back instantaneous payload
            await websocket.send_json({
                "type": "ANALYSIS_UPDATE",
                "payload": analysis
            })
    except WebSocketDisconnect:
        pass
    except Exception as e:
        await websocket.close(code=1011, reason=str(e))


# Static files mount
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/")
    async def serve_index():
        return FileResponse(os.path.join(static_dir, "index.html"))
