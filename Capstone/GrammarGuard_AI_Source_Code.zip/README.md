# Intelligent System for Automatic Grammar Error Detection and Correction
## Capstone Project: Hybrid Rule-Based and Transformer Architecture

A real-time, full-stack intelligent web application that detects and corrects grammatical errors using a dual-algorithm hybrid framework combining deterministic linguistic rule verification with neural transformer self-attention mechanisms.

---

## 🏛️ Core Capstone Modules

The application is structured around 4 interconnected modules:

### 1. Module 1: Text Input & Preprocessing (`core/module1_preprocessing.py`)
- **Tokenization & Sentence Splitting:** Custom boundary segmenter tracking exact character spans `[start, end]`.
- **Morphological POS Tagging:** Lexicon-backed Penn Treebank tagging (`NN`, `VB`, `VBD`, `JJ`, `RB`, `DT`, etc.).
- **Lemmatization:** Suffix stripping and irregular lemma mapping (`went` → `go`, `children` → `child`).
- **Linguistic Metrics:** Syllable counting, lexical diversity, average sentence length, and character density.

### 2. Module 2: Rule-Based Grammar Error Detection (`core/module2_rule_engine.py`)
- **Subject-Verb Agreement (SVA):** Identifies singular 3rd person and plural mismatches (e.g., *"She walk"* → *"She walks"*).
- **Article & Determiner Usage:** Enforces phonetic vowel/consonant rules (e.g., *"an book"* → *"a book"*, *"a hour"* → *"an hour"*).
- **Tense & Auxiliary Consistency:** Enforces modal verb bases (*"will went"* → *"will go"*) and past auxiliary forms (*"did not knew"* → *"did not know"*).
- **Homophones & Confusables:** Differentiates *their/there/they're*, *your/you're*, *its/it's*, *affect/effect*, and *then/than*.
- **Style, Redundancy, & Mechanics:** Catches pleonasms (*"revert back"*, *"advance warning"*) and punctuation spacing errors.

### 3. Module 3: Transformer-Based Grammar Correction (`core/module3_transformer.py`)
- **Contextual Fluency & Collocations:** Detects idiomatic and prepositional issues (*"interested about"* → *"interested in"*, *"discuss about"* → *"discuss"*, *"do a decision"* → *"make a decision"*).
- **Self-Attention Matrix Computation:** Computes Scaled Dot-Product Self-Attention:
  $$\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$
- **Interactive 2D Heatmap:** Renders live token-to-token attention weights in the dashboard.
- **Fluency & Perplexity Scoring:** Evaluates semantic flow and language model confidence.

### 4. Module 4: Hybrid Integration & Error Resolution (`core/module4_hybrid_arbiter.py`)
- **Spatial Collision Detection:** Detects overlapping spans between rule hits and transformer suggestions.
- **Ensemble Decision Matrix:**
  - **Consensus:** Both systems agree on the correction ($F_{0.5}$ confidence: 0.99).
  - **Syntax Precedence:** Deterministic rules override loose neural rewrites for strict structural grammar (SVA, Articles).
  - **Fluency Precedence:** Transformer suggestions are adopted for non-deterministic phrasing and collocations.
- **Text Reconstruction:** Splices non-overlapping corrections without character offset corruption.
- **Unified Diff Generator:** Visualizes added (`+`) and removed (`-`) text in real time.

---

## ⚡ Real-Time Web Application & Dashboard

- **Asynchronous WebSocket Engine:** Keystroke streaming with `< 30ms` latency.
- **Dual-Layer Interactive Editor:** Synchronized underlay highlighting with color-coded underlines:
  - 🟡 **Yellow / Amber:** Rule-based detection
  - 🟣 **Purple / Violet:** Transformer fluency suggestion
  - 🟢 **Emerald / Green:** Hybrid arbitrated resolution
- **Interactive Diagnostics Center:** Live tabs for each module.
- **Real-Time Telemetry Dashboard:**
  - Animated circular Grammar Health meter (0–100)
  - Flesch Reading Ease & Flesch-Kincaid Grade Level
  - Rule vs. Transformer contribution ratio
  - Module processing latencies in milliseconds
- **Audit Export:** One-click generation of formal Markdown/JSON project audit reports.

---

## 🚀 Getting Started

### Prerequisites
- Python 3.10+ (Tested on Python 3.14)
- `fastapi`, `uvicorn`, `websockets`, `pydantic`, `numpy`

### Launching the Application
Run the launcher script:
```bash
python run.py
```
Or run directly via Uvicorn:
```bash
uvicorn server:app --host 127.0.0.1 --port 8000
```
Open your browser at:
👉 **`http://127.0.0.1:8000`**

### Running Individual Modules Standalone
Each module has its own independent source code implementation and can be run and tested in isolation:

```bash
# Module 1: Preprocessing & Penn Treebank POS Tagging
python core/module1_preprocessing.py

# Module 2: Linguistic Rule Engine (SVA, Articles, Modals, Homophones)
python core/module2_rule_engine.py

# Module 3: Transformer-Based Correction & Neural Attention Matrix
python core/module3_transformer.py

# Module 4: Hybrid Collision Detection & Confidence Arbiter
python core/module4_hybrid_arbiter.py

# Analytics & Readability Metrics Engine
python core/metrics.py

# End-to-End Orchestrated Pipeline CLI
python core/pipeline.py
```

### Running the Test Suite
```bash
# Verify all 4 modules
python tests/test_modules.py

# Verify real-time WebSocket communication
python tests/test_websocket.py
```

---

## 📡 API Reference

| Method | Endpoint | Description |
|---|---|---|
| `WS` | `/ws/grammar` | Real-time bidirectional WebSocket stream for keystroke analysis |
| `POST` | `/api/analyze` | Full 4-module deep analysis on input text payload |
| `POST` | `/api/module1/preprocess` | Standalone execution for Module 1: Preprocessing & POS tagging |
| `POST` | `/api/module2/rules` | Standalone execution for Module 2: Rule-based error detection |
| `POST` | `/api/module3/transformer` | Standalone execution for Module 3: Transformer fluency & attention |
| `POST` | `/api/module4/hybrid` | Standalone execution for Module 4: Hybrid arbitration & diff generation |
| `GET` | `/api/samples` | Curated benchmark sample datasets for each error category |
| `POST` | `/api/export` | Generates downloadable Capstone Audit Report (Markdown/JSON) |
| `GET` | `/api/health` | System health and module readiness check |

