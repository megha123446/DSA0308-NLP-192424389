"""
Verification script for Document File Upload (.docx, .pdf, .txt) & Download APIs
"""

import io
import docx
import pypdf
import urllib.request
import urllib.parse
import json


def test_file_upload_and_download():
    # 1. Create in-memory DOCX with complex grammar errors
    doc = docx.Document()
    doc.add_heading("Capstone Test Document", 0)
    doc.add_paragraph("The box of chocolates are on the table, and everyone have arrived.")
    doc.add_paragraph("Between you and I, she has went home because its raining.")
    doc.add_paragraph("The researchers will discuss about the proposal tomorrow.")
    docx_buf = io.BytesIO()
    doc.save(docx_buf)
    docx_bytes = docx_buf.getvalue()

    # 2. Upload DOCX to /api/upload
    boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
    body = bytearray()
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(b'Content-Disposition: form-data; name="file"; filename="test_capstone.docx"\r\n')
    body.extend(b'Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document\r\n\r\n')
    body.extend(docx_bytes)
    body.extend(f"\r\n--{boundary}--\r\n".encode())

    req = urllib.request.Request(
        "http://127.0.0.1:8000/api/upload",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST"
    )

    with urllib.request.urlopen(req) as resp:
        assert resp.status == 200
        data = json.loads(resp.read().decode())
        print("[OK] DOCX File Upload Successful!")
        print(f"  Filename: {data['filename']}, Size: {data['file_size_kb']} KB")
        print(f"  Extracted Words: {data['analysis']['module1_preprocessing']['stats']['word_count']}")
        print(f"  Violations Flagged: {data['analysis']['metrics']['total_errors_detected']}")
        print(f"  Resolved Edits: {len(data['analysis']['module4_hybrid']['resolved_edits'])}")
        print(f"  Final Text: {data['analysis']['module4_hybrid']['final_corrected_text']}")

    # 3. Test Download Corrected Document endpoint
    dl_payload = json.dumps({
        "text": data["extracted_text"],
        "corrected_text": data["analysis"]["module4_hybrid"]["final_corrected_text"],
        "format": "docx",
        "filename": "verified_result"
    }).encode("utf-8")

    dl_req = urllib.request.Request(
        "http://127.0.0.1:8000/api/download-corrected",
        data=dl_payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    with urllib.request.urlopen(dl_req) as dl_resp:
        assert dl_resp.status == 200
        dl_bytes = dl_resp.read()
        print(f"[OK] Download Corrected DOCX Successful! Received {len(dl_bytes)} bytes.")

    # 4. Test Plain Text (.txt) Upload
    txt_content = b"She walk to school yesterday. They was happy so they played in the park."
    body_txt = bytearray()
    body_txt.extend(f"--{boundary}\r\n".encode())
    body_txt.extend(b'Content-Disposition: form-data; name="file"; filename="essay.txt"\r\n')
    body_txt.extend(b'Content-Type: text/plain\r\n\r\n')
    body_txt.extend(txt_content)
    body_txt.extend(f"\r\n--{boundary}--\r\n".encode())

    req_txt = urllib.request.Request(
        "http://127.0.0.1:8000/api/upload",
        data=body_txt,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST"
    )
    with urllib.request.urlopen(req_txt) as resp_txt:
        assert resp_txt.status == 200
        data_txt = json.loads(resp_txt.read().decode())
        print(f"[OK] TXT File Upload Successful! Errors: {data_txt['analysis']['metrics']['total_errors_detected']}")

    # 5. Test PowerPoint (.pptx) Upload
    import pptx
    prs = pptx.Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    slide.shapes.title.text = "The box of chocolates are on the table."
    pptx_buf = io.BytesIO()
    prs.save(pptx_buf)
    pptx_bytes = pptx_buf.getvalue()

    body_pptx = bytearray()
    body_pptx.extend(f"--{boundary}\r\n".encode())
    body_pptx.extend(b'Content-Disposition: form-data; name="file"; filename="sample.pptx"\r\n')
    body_pptx.extend(b'Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation\r\n\r\n')
    body_pptx.extend(pptx_bytes)
    body_pptx.extend(f"\r\n--{boundary}--\r\n".encode())

    req_pptx = urllib.request.Request(
        "http://127.0.0.1:8000/api/upload",
        data=body_pptx,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST"
    )
    with urllib.request.urlopen(req_pptx) as resp_pptx:
        assert resp_pptx.status == 200
        data_pptx = json.loads(resp_pptx.read().decode())
        print(f"[OK] PPTX File Upload Successful! Extracted: '{data_pptx['extracted_text']}'")
        print(f"  Resolved: '{data_pptx['analysis']['module4_hybrid']['final_corrected_text']}'")

    print("\nALL FILE UPLOAD & EXPORT TESTS PASSED PERFECTLY!")


if __name__ == "__main__":
    test_file_upload_and_download()
