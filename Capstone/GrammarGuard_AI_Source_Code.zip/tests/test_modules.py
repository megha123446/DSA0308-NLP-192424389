"""
Validation tests for the 4 Capstone Modules:
Module 1: Preprocessing
Module 2: Rule Engine
Module 3: Transformer Engine
Module 4: Hybrid Resolver
"""

import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from core.pipeline import GrammarSystemPipeline


def test_capstone_pipeline():
    pipeline = GrammarSystemPipeline()

    # Test sentence containing errors across categories:
    # 1. "She walk" -> SVA error (Module 2)
    # 2. "an book" -> Article error (Module 2)
    # 3. "interested about" -> Preposition/Collocation (Module 3)
    # 4. "will went" -> Tense modal error (Module 2)
    test_text = "She walk to library and bought an book. He was interested about learning, but will went home early."

    print("Analyzing test text:\n", test_text)
    result = pipeline.analyze(test_text)

    # 1. Module 1 checks
    m1 = result["module1_preprocessing"]
    print(f"\n[Module 1 Preprocessing] Sentences: {len(m1['sentences'])}, Tokens: {len(m1['tokens'])}, Words: {m1['stats']['word_count']}")
    assert len(m1["sentences"]) >= 1, "Module 1 failed sentence segmentation"
    assert len(m1["tokens"]) > 0, "Module 1 failed tokenization"

    # 2. Module 2 checks
    m2 = result["module2_rule_engine"]
    print(f"[Module 2 Rule Engine] Violations detected: {m2['violations_count']}")
    assert m2["violations_count"] >= 3, f"Expected at least 3 rule violations, got {m2['violations_count']}"
    rule_names = [v["rule_name"] for v in m2["violations"]]
    print("  Triggered rules:", rule_names)

    # 3. Module 3 checks
    m3 = result["module3_transformer"]
    print(f"[Module 3 Transformer] Suggestions: {len(m3['suggestions'])}, Fluency: {m3['fluency_score']}")
    assert len(m3["attention_map"]["matrix"]) > 0, "Transformer attention matrix empty"
    print("  Attention matrix shape:", len(m3["attention_map"]["matrix"]), "x", len(m3["attention_map"]["matrix"][0]))

    # 4. Module 4 checks
    m4 = result["module4_hybrid"]
    print(f"[Module 4 Hybrid Resolution] Total resolved edits: {len(m4['resolved_edits'])}")
    print(f"  Final Corrected Text:\n  '{m4['final_corrected_text']}'")
    assert len(m4["resolved_edits"]) >= 3, "Module 4 failed to resolve edits"
    assert "walks" in m4["final_corrected_text"], "SVA correction missing from final text"
    assert "a book" in m4["final_corrected_text"], "Article correction missing from final text"

    # 5. Metrics & Latency
    metrics = result["metrics"]
    print(f"\n[Dashboard Metrics] Grammar Health: {metrics['grammar_health_score']}/100, Total Pipeline Latency: {metrics['latencies_ms']['total_pipeline']} ms")
    assert metrics["latencies_ms"]["total_pipeline"] < 250.0, "Latency exceeded real-time budget"


def test_complex_grammar():
    pipeline = GrammarSystemPipeline()
    complex_text = (
        "The box of chocolates are on the table, and everyone have arrived. "
        "Between you and I, she has went home early because its raining. "
        "The committee will discuss about the proposal tomorrow."
    )
    print("\n" + "=" * 60)
    print("Testing Complex Grammar Suite:\n", complex_text)
    res = pipeline.analyze(complex_text)
    corrected = res["module4_hybrid"]["final_corrected_text"]
    print("Corrected:\n", corrected)

    assert "box of chocolates is" in corrected, "Intervening SVA failed"
    assert "everyone has" in corrected, "Indefinite pronoun SVA failed"
    assert "Between you and me" in corrected, "Pronoun case failed"
    assert "she has gone" in corrected, "Perfect aspect participle failed"
    assert "because it's raining" in corrected, "Homophone failed"
    assert "will discuss the proposal" in corrected, "Transitive verb collocation failed"
    print("ALL COMPLEX GRAMMAR ASSERTIONS PASSED!")


if __name__ == "__main__":
    test_capstone_pipeline()
    test_complex_grammar()
    print("\nALL MODULE TESTS PASSED SUCCESSFULLY!")
