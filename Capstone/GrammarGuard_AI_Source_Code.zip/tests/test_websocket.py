"""
Verification script for WebSocket real-time communication
"""

import asyncio
import websockets
import json


async def test_ws():
    uri = "ws://127.0.0.1:8000/ws/grammar"
    async with websockets.connect(uri) as ws:
        test_payload = {
            "text": "She walk to library and bought an book. He was interested about learning, but will went home early."
        }
        await ws.send(json.dumps(test_payload))
        response = await ws.recv()
        data = json.loads(response)
        
        print("WebSocket Response Received!")
        print("Response type:", data.get("type"))
        payload = data.get("payload", {})
        print("M1 Words:", payload["module1_preprocessing"]["stats"]["word_count"])
        print("M2 Violations:", payload["module2_rule_engine"]["violations_count"])
        print("M3 Suggestions:", len(payload["module3_transformer"]["suggestions"]))
        print("M4 Resolved Edits:", len(payload["module4_hybrid"]["resolved_edits"]))
        print("M4 Corrected Text:", payload["module4_hybrid"]["final_corrected_text"])
        print("Total Latency:", payload["metrics"]["latencies_ms"]["total_pipeline"], "ms")
        print("\nWEBSOCKET VERIFICATION PASSED!")


if __name__ == "__main__":
    asyncio.run(test_ws())
