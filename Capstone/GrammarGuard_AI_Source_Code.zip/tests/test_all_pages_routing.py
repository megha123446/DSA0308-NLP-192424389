import urllib.request
import json
import re

BASE_URL = "http://127.0.0.1:8000"

def test_all_pages():
    print("Verifying all 5 pages and real-time functionality...")
    
    # 1. Fetch HTML
    req = urllib.request.urlopen(f"{BASE_URL}/")
    assert req.status == 200, f"Root returned {req.status}"
    html = req.read().decode("utf-8")
    
    # Check all 5 views exist
    views = ["viewDashboard", "viewUpload", "viewHistory", "viewAnalytics", "viewSettings"]
    for v in views:
        assert f'id="{v}"' in html, f"Missing view: {v} in index.html"
        print(f"[OK] Found view container: #{v}")
        
    # Check all 5 nav links exist with data-view
    for v in views:
        assert f'data-view="{v}"' in html, f"Missing nav link with data-view='{v}'"
        print(f"[OK] Found nav link targeting: {v}")
        
    # 2. Check JavaScript
    req = urllib.request.urlopen(f"{BASE_URL}/static/js/app.js")
    assert req.status == 200, f"app.js returned {req.status}"
    js_content = req.read().decode("utf-8")
    assert "switchView" in js_content, "Missing switchView in app.js"
    assert "viewDashboard" in js_content, "Missing viewDashboard in app.js"
    assert "viewUpload" in js_content, "Missing viewUpload in app.js"
    assert "viewHistory" in js_content, "Missing viewHistory in app.js"
    assert "viewAnalytics" in js_content, "Missing viewAnalytics in app.js"
    assert "viewSettings" in js_content, "Missing viewSettings in app.js"
    print(f"[OK] app.js contains full SPA router and handlers (size: {len(js_content)} bytes)")
    
    # 3. Check CSS
    req = urllib.request.urlopen(f"{BASE_URL}/static/css/styles.css")
    assert req.status == 200, f"styles.css returned {req.status}"
    css_content = req.read().decode("utf-8")
    assert ".app-view" in css_content
    assert ".app-view.active" in css_content
    assert ".analytics-top-kpis" in css_content
    assert ".settings-two-col" in css_content
    print(f"[OK] styles.css contains rules for all 5 views (size: {len(css_content)} bytes)")
    
    # 4. Check API endpoints
    # /api/analyze
    data = json.dumps({"text": "She go to the market yesterday."}).encode("utf-8")
    req = urllib.request.Request(f"{BASE_URL}/api/analyze", data=data, headers={"Content-Type": "application/json"})
    resp = urllib.request.urlopen(req)
    assert resp.status == 200
    res_json = json.loads(resp.read().decode("utf-8"))
    corr = res_json["module4_hybrid"]["final_corrected_text"]
    assert "went" in corr, f"Expected 'went' in correction, got: {corr}"
    print(f"[OK] /api/analyze real-time correction verified: '{corr}'")
    
    # /api/samples
    req = urllib.request.urlopen(f"{BASE_URL}/api/samples")
    assert req.status == 200
    samples = json.loads(req.read().decode("utf-8"))
    assert len(samples) >= 5
    print(f"[OK] /api/samples returned {len(samples)} benchmark datasets")
    
    print("\n>>> ALL 5 PAGES AND REAL-TIME ROUTING VERIFIED SUCCESSFULLY! <<<")

if __name__ == "__main__":
    test_all_pages()
