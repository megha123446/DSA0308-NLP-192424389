import urllib.request
import urllib.parse
import json

BASE_URL = "http://127.0.0.1:8000"

def test_endpoints():
    print("Testing server endpoints at", BASE_URL)
    
    # 1. GET /
    req = urllib.request.urlopen(f"{BASE_URL}/")
    assert req.status == 200, f"Root returned {req.status}"
    html = req.read().decode("utf-8")
    assert "GrammarGuard" in html, "GrammarGuard not found in HTML"
    assert "app.js" in html, "app.js not linked in HTML"
    assert "styles.css" in html, "styles.css not linked in HTML"
    print("[OK] GET / returned 200 with valid HTML")
    
    # 2. GET /static/js/app.js
    req = urllib.request.urlopen(f"{BASE_URL}/static/js/app.js")
    assert req.status == 200, f"app.js returned {req.status}"
    js_content = req.read().decode("utf-8")
    assert "GrammarGuard AI" in js_content, "app.js header missing"
    print("[OK] GET /static/js/app.js returned 200 with valid JS (size: {} bytes)".format(len(js_content)))
    
    # 3. GET /static/css/styles.css
    req = urllib.request.urlopen(f"{BASE_URL}/static/css/styles.css")
    assert req.status == 200, f"styles.css returned {req.status}"
    css_content = req.read().decode("utf-8")
    assert "pipe-step-card" in css_content, "styles.css missing pipeline classes"
    print("[OK] GET /static/css/styles.css returned 200 (size: {} bytes)".format(len(css_content)))
    
    # 4. POST /api/analyze
    data = json.dumps({"text": "The student are trying to finish their project."}).encode("utf-8")
    req = urllib.request.Request(f"{BASE_URL}/api/analyze", data=data, headers={"Content-Type": "application/json"})
    resp = urllib.request.urlopen(req)
    assert resp.status == 200, f"api/analyze returned {resp.status}"
    analysis = json.loads(resp.read().decode("utf-8"))
    assert "module1_preprocessing" in analysis
    assert "module4_hybrid" in analysis
    print("[OK] POST /api/analyze returned 200 with full 4-module analysis")
    print("    Original: The student are trying to finish their project.")
    print("    Corrected:", analysis["module4_hybrid"]["final_corrected_text"])
    
    # 5. POST /api/download-corrected
    payload = {
        "text": "The student are trying to finish their project.",
        "corrected_text": "The student is trying to finish their project.",
        "format": "docx",
        "filename": "Grammar_Report"
    }
    req = urllib.request.Request(
        f"{BASE_URL}/api/download-corrected",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"}
    )
    resp = urllib.request.urlopen(req)
    assert resp.status == 200, f"download-corrected returned {resp.status}"
    docx_bytes = resp.read()
    assert len(docx_bytes) > 500, "DOCX output too small"
    print("[OK] POST /api/download-corrected returned 200 with valid DOCX binary (size: {} bytes)".format(len(docx_bytes)))

    print("\nALL BACKEND & STATIC VERIFICATIONS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_endpoints()
