/**
 * GrammarGuard AI - Multi-View SaaS Application Engine
 * Drives all 5 views seamlessly:
 *   1. Dashboard (Operational Real-Time Dual-Engine Editor & Inspection Deck)
 *   2. Upload & Process (Drag & Drop, Supported Formats, Quick Stats, Vertical Stepper)
 *   3. History (Search, Status Filter, Date Filter, Pagination, Actions)
 *   4. Analysis & Insights (KPIs, Donut Charts, Accuracy Trend Graph, Top Issues)
 *   5. Settings (Profile, Change Password, System Preference Toggles, Language & Region)
 */

(function () {
  'use strict';

  // Application State
  let activeDocument = {
    filename: "Grammar_Report.docx",
    filesize: "2.4 MB",
    uploadTime: "Uploaded just now",
    format: "docx",
    originalText: "The student are trying to finish their project.\nShe go to the market yesterday.\nThis is a good example of how AI can help us.\nWe need to improves the system performance.\nI am looking forward to see the results.",
    correctedText: "The student is trying to finish their project.\nShe went to the market yesterday.\nThis is a good example of how AI can help us.\nWe need to improve the system performance.\nI am looking forward to seeing the results.",
    errors: [
      { id: 1, line: 1, original: "are", replacement: "is", rule: "Subject-verb agreement error", desc: "Singular subject 'The student' requires singular verb 'is'." },
      { id: 2, line: 2, original: "go", replacement: "went", rule: "Incorrect verb tense", desc: "Past temporal marker 'yesterday' requires past tense verb 'went'." },
      { id: 3, line: 4, original: "improves", replacement: "improve", rule: "Verb form error", desc: "Infinitive marker 'to' requires base verb form 'improve'." },
      { id: 4, line: 5, original: "see", replacement: "seeing", rule: "Incorrect verb usage", desc: "Prepositional idiom 'looking forward to' requires gerund 'seeing'." },
      { id: 5, line: 2, original: ". (extra space)", replacement: ".", rule: "Punctuation/spacing error", desc: "Redundant whitespace before punctuation mark removed." }
    ],
    totalErrors: 37,
    qualityScore: 98,
    words: 2486,
    sentences: 142,
    tokens: 1823
  };

  // Pre-populated History Records Matching Reference Screenshot
  let historyRecords = [
    { name: "Research_Paper.pdf", type: "PDF", uploaded: "Apr 26, 2025 10:24", status: "completed", accuracy: "96% ↑", text: "The quality of these products are superior than previous designs. Everyone have contributed." },
    { name: "Project_Report.docx", type: "DOCX", uploaded: "Apr 26, 2025 09:15", status: "completed", accuracy: "94%", text: "The box of chocolates are on the table. She has went home early because its raining." },
    { name: "Presentation.pptx", type: "PPTX", uploaded: "Apr 25, 2025 16:32", status: "completed", accuracy: "92%", text: "The committee will discuss about the proposal tomorrow. Researchers must do a decision." },
    { name: "Article_Draft.docx", type: "DOCX", uploaded: "Apr 24, 2025 14:20", status: "completed", accuracy: "90%", text: "She go to school yesterday and her friend was waiting for her at the gate." },
    { name: "Thesis_Chapter.pdf", type: "PDF", uploaded: "Apr 23, 2025 11:10", status: "completed", accuracy: "96%", text: "It was an unique opportunity to conduct a interview. She waited for an hour to meet an European professor." },
    { name: "Marketing_Content.pptx", type: "PPTX", uploaded: "Apr 22, 2025 15:45", status: "failed", accuracy: "-", text: "Marketing draft with unformatted binary contents." },
    { name: "Business_Doc.docx", type: "DOCX", uploaded: "Apr 20, 2025 13:30", status: "completed", accuracy: "88%", text: "Between you and I, he don't have no money for less people." },
    { name: "Research_Notes.pdf", type: "PDF", uploaded: "Apr 18, 2025 10:12", status: "completed", accuracy: "93%", text: "The authors revert back to past history and discuss about the end result." }
  ];

  // Recent files in View 2
  let recentFiles = [
    { name: "Research_Paper.pdf", type: "PDF", size: "2.4 MB", uploaded: "Apr 26, 2025 10:24", status: "processing" },
    { name: "Project_Report.docx", type: "DOCX", size: "1.8 MB", uploaded: "Apr 26, 2025 09:15", status: "completed" },
    { name: "Presentation.pptx", type: "PPTX", size: "4.2 MB", uploaded: "Apr 25, 2025 16:32", status: "completed" },
    { name: "Article_Draft.docx", type: "DOCX", size: "1.1 MB", uploaded: "Apr 24, 2025 14:20", status: "completed" }
  ];

  let ws = null;
  let isProcessing = false;

  /* ==========================================================================
     1. INITIALIZATION & ROUTING
     ========================================================================== */
  function init() {
    initNavigation();
    initDashboard();
    initUploadAndProcessView();
    initHistoryView();
    initAnalyticsView();
    initSettingsView();
    initFullDocModal();
    initWebSocket();

    // Check URL Hash for initial view
    handleInitialHash();

    // Smooth demo transition on dashboard
    setTimeout(() => {
      completeInitialProcessingTransition();
    }, 2800);
  }

  function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.app-view');

    navItems.forEach(item => {
      item.addEventListener('click', function (e) {
        e.preventDefault();
        const targetViewId = this.getAttribute('data-view');
        if (!targetViewId) return;

        switchView(targetViewId, this);
      });
    });

    // "View All" link in Recent Files switches to History view
    const linkViewAllRecent = document.getElementById('linkViewAllRecent');
    if (linkViewAllRecent) {
      linkViewAllRecent.addEventListener('click', (e) => {
        e.preventDefault();
        const navHist = document.getElementById('navHistory');
        if (navHist) navHist.click();
      });
    }

    // Bell notifications button
    const bellBtn = document.querySelector('.bell-btn');
    if (bellBtn) {
      bellBtn.addEventListener('click', () => {
        showToast("🔔 3 Unread Alerts: Grammar_Report.docx analyzed, 37 corrections applied.");
      });
    }
  }

  function switchView(viewId, activeNavItem) {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.app-view');

    // Update Nav
    navItems.forEach(n => n.classList.remove('active'));
    if (activeNavItem) {
      activeNavItem.classList.add('active');
    } else {
      const match = document.querySelector(`.nav-item[data-view="${viewId}"]`);
      if (match) match.classList.add('active');
    }

    // Update Views
    views.forEach(v => v.classList.remove('active'));
    const targetView = document.getElementById(viewId);
    if (targetView) {
      targetView.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Update Hash without jump
    const hashName = viewId.replace('view', '').toLowerCase();
    history.replaceState(null, null, `#${hashName}`);
  }

  function handleInitialHash() {
    const hash = window.location.hash.replace('#', '').toLowerCase();
    const map = {
      'dashboard': 'viewDashboard',
      'upload': 'viewUpload',
      'history': 'viewHistory',
      'analytics': 'viewAnalytics',
      'settings': 'viewSettings'
    };

    if (hash && map[hash]) {
      switchView(map[hash]);
    }
  }

  /* ==========================================================================
     2. VIEW 1: DASHBOARD
     ========================================================================== */
  function initDashboard() {
    // Drop Zone in Dashboard
    const dropZone = document.getElementById('dropZone');
    const fileUploadInput = document.getElementById('fileUploadInput');
    const btnBrowseFiles = document.getElementById('btnBrowseFiles');
    const btnClearFilePill = document.getElementById('btnClearFilePill');

    if (btnBrowseFiles && fileUploadInput) {
      btnBrowseFiles.addEventListener('click', () => fileUploadInput.click());
    }

    if (fileUploadInput) {
      fileUploadInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
          processUploadedFile(e.target.files[0]);
        }
      });
    }

    if (dropZone) {
      ['dragenter', 'dragover'].forEach(name => {
        dropZone.addEventListener(name, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropZone.style.borderColor = 'var(--cyan)';
          dropZone.style.background = 'rgba(0, 216, 255, 0.05)';
        });
      });

      ['dragleave', 'drop'].forEach(name => {
        dropZone.addEventListener(name, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropZone.style.borderColor = '';
          dropZone.style.background = '';
        });
      });

      dropZone.addEventListener('drop', (e) => {
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          processUploadedFile(e.dataTransfer.files[0]);
        }
      });
    }

    if (btnClearFilePill) {
      btnClearFilePill.addEventListener('click', () => {
        const uploadedDocName = document.getElementById('uploadedDocName');
        const uploadedDocMeta = document.getElementById('uploadedDocMeta');
        if (uploadedDocName) uploadedDocName.textContent = "No document selected";
        if (uploadedDocMeta) uploadedDocMeta.textContent = "Drag & drop or browse to upload";
        showToast("Ready for new document upload.");
      });
    }

    // Download Button
    const btnDownloadCorrectedDoc = document.getElementById('btnDownloadCorrectedDoc');
    if (btnDownloadCorrectedDoc) {
      btnDownloadCorrectedDoc.addEventListener('click', () => {
        downloadDocumentFile(activeDocument.filename, activeDocument.originalText, activeDocument.correctedText);
      });
    }

    // Render Initial State
    renderDashboard(activeDocument);
  }

  function renderDashboard(doc) {
    const uploadedDocName = document.getElementById('uploadedDocName');
    const uploadedDocMeta = document.getElementById('uploadedDocMeta');
    const uploadedBadgeIcon = document.getElementById('uploadedBadgeIcon');
    const alertErrorsCount = document.getElementById('alertErrorsCount');
    const qualityScoreTag = document.getElementById('qualityScoreTag');

    if (uploadedDocName) uploadedDocName.textContent = doc.filename;
    if (uploadedDocMeta) uploadedDocMeta.textContent = `${doc.filesize} • ${doc.uploadTime}`;
    if (uploadedBadgeIcon) {
      const ext = (doc.format || 'docx').toLowerCase().replace('.', '');
      uploadedBadgeIcon.className = `fmt-icon ${ext === 'pdf' ? 'pdf' : ext === 'pptx' ? 'pptx' : 'docx'}`;
      uploadedBadgeIcon.textContent = ext === 'pdf' ? 'PDF' : ext === 'pptx' ? 'P3' : 'Wrd';
    }

    if (alertErrorsCount) alertErrorsCount.textContent = doc.totalErrors;
    if (qualityScoreTag) qualityScoreTag.textContent = `Quality Score: ${doc.qualityScore}%`;

    renderOriginalLines(doc.originalText, doc.errors);
    renderDetectedSuggestions(doc.errors);
    renderCorrectedLines(doc.correctedText);
  }

  function renderOriginalLines(text, errors) {
    const originalLinesBox = document.getElementById('originalLinesBox');
    if (!originalLinesBox) return;

    const lines = text.split('\n').filter(l => l.trim().length > 0);
    let html = '';

    lines.forEach((line, idx) => {
      const lineNum = idx + 1;
      let highlightedLine = escapeHtml(line);

      const lineErrors = errors.filter(e => e.line === lineNum || (!e.line && line.includes(e.original)));
      lineErrors.forEach(err => {
        if (err.original && err.original.trim() && !err.original.includes('space')) {
          const regex = new RegExp(`\\b(${escapeRegex(err.original)})\\b`, 'gi');
          highlightedLine = highlightedLine.replace(regex, `<span class="hl-err-tag" data-err-id="${err.id}">$1</span>`);
        }
      });

      html += `<div class="code-line" id="origLine-${lineNum}">
        <span class="line-num">${lineNum}</span>
        <span>${highlightedLine}</span>
      </div>`;
    });

    originalLinesBox.innerHTML = html;
  }

  function renderCorrectedLines(text) {
    const correctedLinesBox = document.getElementById('correctedLinesBox');
    if (!correctedLinesBox) return;

    const lines = text.split('\n').filter(l => l.trim().length > 0);
    let html = '';

    const fixKeywords = ['is', 'went', 'improve', 'seeing', 'exceptional', 'an interview', 'fewer people', 'revert to', 'reach a decision', 'superior to', 'has gone', 'has seen', 'did not know', 'will go', 'because it is', 'each of the students has', 'nor the employees were'];

    lines.forEach((line, idx) => {
      const lineNum = idx + 1;
      let highlightedLine = escapeHtml(line);

      fixKeywords.forEach(word => {
        const regex = new RegExp(`\\b(${escapeRegex(word)})\\b`, 'gi');
        highlightedLine = highlightedLine.replace(regex, `<span class="hl-fix-tag">$1</span>`);
      });

      html += `<div class="code-line" id="corrLine-${lineNum}">
        <span class="line-num">${lineNum}</span>
        <span>${highlightedLine}</span>
      </div>`;
    });

    correctedLinesBox.innerHTML = html;
  }

  function renderDetectedSuggestions(errors) {
    const detectedSuggBox = document.getElementById('detectedSuggBox');
    if (!detectedSuggBox) return;

    let html = '';
    errors.forEach((err, idx) => {
      const displayNum = idx + 1;
      const arrowText = `${err.original} → ${err.replacement}`;

      html += `<div class="err-sugg-row" data-err-id="${err.id}" data-err-line="${err.line || 1}">
        <div class="err-sugg-left">
          <span style="font-size: 0.75rem; color: var(--text-muted); font-family: var(--font-mono);">${displayNum}</span>
          <span class="err-pill-badge">${escapeHtml(arrowText)}</span>
          <span style="color: var(--text-secondary); font-size: 0.78rem;">${escapeHtml(err.rule || err.desc || 'Grammar error')}</span>
        </div>
        <span class="arrow-right-icon">→</span>
      </div>`;
    });

    detectedSuggBox.innerHTML = html;

    const rows = detectedSuggBox.querySelectorAll('.err-sugg-row');
    rows.forEach(row => {
      row.addEventListener('click', function () {
        const lineNum = this.getAttribute('data-err-line');
        const errId = this.getAttribute('data-err-id');
        focusErrorLine(lineNum, errId);
      });
    });
  }

  function focusErrorLine(lineNum, errId) {
    document.querySelectorAll('.code-line.focused-line').forEach(el => el.classList.remove('focused-line'));

    const origLine = document.getElementById(`origLine-${lineNum}`);
    const corrLine = document.getElementById(`corrLine-${lineNum}`);

    if (origLine) {
      origLine.classList.add('focused-line');
      origLine.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    if (corrLine) {
      corrLine.classList.add('focused-line');
      corrLine.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    const errorItem = activeDocument.errors.find(e => String(e.id) === String(errId));
    if (errorItem) {
      showToast(`Focused: "${errorItem.original}" → "${errorItem.replacement}" (${errorItem.rule})`);
    }
  }

  function updateDonutProgress(percent) {
    const liveDonutCircle = document.getElementById('liveDonutCircle');
    const liveProgressPct = document.getElementById('liveProgressPct');
    if (!liveDonutCircle || !liveProgressPct) return;

    const circumference = 276.46;
    const offset = circumference - (percent / 100) * circumference;
    liveDonutCircle.style.strokeDashoffset = offset;
    liveProgressPct.textContent = `${Math.round(percent)}%`;
  }

  function setStepStatus(stepNum, status, timingText) {
    const mini = document.getElementById(`miniStep${stepNum}`);
    if (mini) {
      mini.className = `step-status-tag ${status}`;
      if (status === 'done') mini.innerHTML = `Completed &nbsp;${timingText || '12s'}`;
      else if (status === 'in-progress') mini.innerHTML = `In Progress &nbsp;${timingText || '10s'}`;
      else mini.innerHTML = `Pending &nbsp;-`;
    }

    const card = document.getElementById(`pipeCard${stepNum}`);
    const pill = document.getElementById(`pipePill${stepNum}`);

    if (card) {
      if (status === 'in-progress') card.classList.add('active');
      else card.classList.remove('active');
    }

    if (pill) {
      pill.className = `pipe-status-pill ${status}`;
      if (status === 'done') pill.innerHTML = `✓ Completed`;
      else if (status === 'in-progress') pill.innerHTML = `🔄 In Progress`;
      else pill.innerHTML = `⏳ Pending`;
    }
  }

  function appendLog(message) {
    const terminalLogsBox = document.getElementById('terminalLogsBox');
    if (!terminalLogsBox) return;
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const logItem = document.createElement('div');
    logItem.className = 'log-entry';
    logItem.innerHTML = `<span class="log-time">${timeStr}</span> ${escapeHtml(message)}`;
    terminalLogsBox.appendChild(logItem);
    terminalLogsBox.scrollTop = terminalLogsBox.scrollHeight;
  }

  function completeInitialProcessingTransition() {
    setStepStatus(3, 'done', '52s');
    setStepStatus(4, 'in-progress', '14s');
    updateDonutProgress(84);
    const currentTaskDesc = document.getElementById('currentTaskDesc');
    const processingStatusBadge = document.querySelector('.processing-status-badge');
    const logProcessingTime = document.getElementById('logProcessingTime');
    const logEstTime = document.getElementById('logEstTime');

    if (currentTaskDesc) currentTaskDesc.textContent = "Hybrid arbiter validating rule & transformer error agreements...";

    setTimeout(() => {
      setStepStatus(4, 'done', '22s');
      setStepStatus(5, 'in-progress', '6s');
      updateDonutProgress(95);
      if (currentTaskDesc) currentTaskDesc.textContent = "Calculating neural token attention and quality score...";
      appendLog("Transformer correction completed (98.4% confidence)");
      appendLog("Hybrid arbiter resolved 37 corrections without conflicts");

      setTimeout(() => {
        setStepStatus(5, 'done', '8s');
        updateDonutProgress(100);
        if (currentTaskDesc) currentTaskDesc.textContent = "Analysis complete. Document ready for download.";
        if (processingStatusBadge) {
          processingStatusBadge.textContent = "✓ Completed";
          processingStatusBadge.style.background = "rgba(16, 185, 129, 0.2)";
          processingStatusBadge.style.borderColor = "var(--success)";
          processingStatusBadge.style.color = "var(--success)";
        }
        if (logProcessingTime) logProcessingTime.textContent = "~ 1 min 15 sec";
        if (logEstTime) logEstTime.textContent = "Ready";
        appendLog("Quality score verified: 98% (Pipeline completed)");
      }, 700);
    }, 800);
  }

  /* ==========================================================================
     3. FILE PROCESSING LOGIC (SHARED BETWEEN DASHBOARD & UPLOAD VIEWS)
     ========================================================================== */
  function processUploadedFile(file) {
    if (!file) return;
    if (isProcessing) {
      showToast("A pipeline run is already in progress...");
      return;
    }

    isProcessing = true;
    const fileName = file.name;
    const fileSizeKb = (file.size / 1024).toFixed(1);
    const ext = fileName.split('.').pop().toLowerCase();

    // Update Dashboard Elements
    const uploadedDocName = document.getElementById('uploadedDocName');
    const uploadedDocMeta = document.getElementById('uploadedDocMeta');
    const uploadedBadgeIcon = document.getElementById('uploadedBadgeIcon');
    const processingStatusBadge = document.querySelector('.processing-status-badge');
    const currentTaskDesc = document.getElementById('currentTaskDesc');
    const terminalLogsBox = document.getElementById('terminalLogsBox');

    if (uploadedDocName) uploadedDocName.textContent = fileName;
    if (uploadedDocMeta) uploadedDocMeta.textContent = `${fileSizeKb} KB • Uploaded just now`;
    if (uploadedBadgeIcon) {
      uploadedBadgeIcon.className = `fmt-icon ${ext === 'pdf' ? 'pdf' : ext === 'pptx' ? 'pptx' : 'docx'}`;
      uploadedBadgeIcon.textContent = ext === 'pdf' ? 'PDF' : ext === 'pptx' ? 'P3' : 'Wrd';
    }

    updateDonutProgress(10);
    if (processingStatusBadge) {
      processingStatusBadge.textContent = "◆ Processing...";
      processingStatusBadge.style.background = "var(--success-bg)";
      processingStatusBadge.style.borderColor = "var(--success)";
      processingStatusBadge.style.color = "var(--success)";
    }
    if (currentTaskDesc) currentTaskDesc.textContent = `Reading & extracting ${ext.toUpperCase()} contents...`;

    if (terminalLogsBox) terminalLogsBox.innerHTML = '';
    appendLog(`File uploaded successfully [${fileName}]`);
    appendLog(`Extracting text and structure (${fileSizeKb} KB)`);

    // Reset Steppers (Horizontal & Vertical)
    setStepStatus(1, 'in-progress', '1s');
    setStepStatus(2, 'pending');
    setStepStatus(3, 'pending');
    setStepStatus(4, 'pending');
    setStepStatus(5, 'pending');
    updateVerticalStepper(1);

    const startTime = performance.now();
    const formData = new FormData();
    formData.append('file', file);

    const animTimer1 = setTimeout(() => {
      setStepStatus(1, 'done', '4ms');
      setStepStatus(2, 'in-progress', '12ms');
      updateVerticalStepper(2);
      updateDonutProgress(35);
      appendLog("Preprocessing completed (normalized text & sentence segmentation)");
      if (currentTaskDesc) currentTaskDesc.textContent = "Rule-based grammar detection in progress...";
    }, 200);

    const animTimer2 = setTimeout(() => {
      setStepStatus(2, 'done', '18ms');
      setStepStatus(3, 'in-progress', '25ms');
      updateVerticalStepper(3);
      updateDonutProgress(65);
      appendLog("Rule-based detection executed across 35 linguistic patterns");
      if (currentTaskDesc) currentTaskDesc.textContent = "Transformer contextual correction & fluency evaluation...";
    }, 450);

    fetch('/api/upload', {
      method: 'POST',
      body: formData
    })
    .then(res => {
      if (!res.ok) throw new Error(`Upload failed with status ${res.status}`);
      return res.json();
    })
    .then(data => {
      clearTimeout(animTimer1);
      clearTimeout(animTimer2);

      const elapsed = Math.round(performance.now() - startTime);
      const analysis = data.analysis || {};
      const extractedText = data.extracted_text || "";

      const m1 = analysis.module1_preprocessing || {};
      const m2 = analysis.module2_rule_detection || {};
      const m4 = analysis.module4_hybrid || {};

      const ruleErrors = m2.errors || [];
      const correctedText = m4.final_corrected_text || extractedText;
      const totalErrors = m4.total_corrections || ruleErrors.length || 0;
      const qualityScore = Math.min(99, Math.max(88, 100 - Math.round((totalErrors / Math.max(1, m1.word_count || 50)) * 100)));

      const formattedErrors = ruleErrors.map((err, idx) => ({
        id: idx + 1,
        line: Math.min(10, Math.floor(idx / 2) + 1),
        original: err.matched_text || err.pattern_id || "error",
        replacement: err.suggested_replacement || "correction",
        rule: err.pattern_id || err.message || "Grammar error",
        desc: err.explanation || err.message || "Rule-based grammar correction"
      }));

      activeDocument = {
        filename: data.filename || fileName,
        filesize: `${data.file_size_kb || fileSizeKb} KB`,
        uploadTime: "Uploaded just now",
        format: data.format || ext,
        originalText: extractedText,
        correctedText: correctedText,
        errors: formattedErrors.length > 0 ? formattedErrors : [
          { id: 1, line: 1, original: "Grammar check", replacement: "Verified", rule: "All rules validated", desc: "No critical grammar errors found." }
        ],
        totalErrors: totalErrors,
        qualityScore: qualityScore,
        words: m1.word_count || 120,
        sentences: m1.sentence_count || 8,
        tokens: m1.token_count || 140
      };

      // Add to Recent Files and History lists
      const now = new Date();
      const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      const dateStr = `${monthNames[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

      recentFiles.unshift({
        name: activeDocument.filename,
        type: ext.toUpperCase(),
        size: activeDocument.filesize,
        uploaded: dateStr,
        status: "completed"
      });
      renderRecentFilesTable();

      historyRecords.unshift({
        name: activeDocument.filename,
        type: ext.toUpperCase(),
        uploaded: dateStr,
        status: "completed",
        accuracy: `${qualityScore}% ↑`,
        text: activeDocument.originalText
      });
      renderHistoryTable();

      // Complete Pipeline Visuals
      setStepStatus(1, 'done', '4ms');
      setStepStatus(2, 'done', '16ms');
      setStepStatus(3, 'done', '24ms');
      setStepStatus(4, 'done', '12ms');
      setStepStatus(5, 'done', '6ms');
      updateVerticalStepper(5);
      updateDonutProgress(100);

      appendLog(`Text extracted (${activeDocument.words} words, ${activeDocument.sentences} sentences)`);
      appendLog(`Rule-based detection identified ${ruleErrors.length} grammar patterns`);
      appendLog(`Hybrid arbiter synthesized final corrections (${totalErrors} total fixes applied)`);
      appendLog(`Pipeline execution finished in ${elapsed} ms`);

      const logProcessingTime = document.getElementById('logProcessingTime');
      const logEstTime = document.getElementById('logEstTime');
      if (logProcessingTime) logProcessingTime.textContent = `~ ${elapsed} ms`;
      if (logEstTime) logEstTime.textContent = "Ready";

      renderDashboard(activeDocument);
      showToast(`✓ Document "${fileName}" processed successfully!`);
      isProcessing = false;
    })
    .catch(err => {
      console.error("Upload failed:", err);
      appendLog(`Error: ${err.message}`);
      showToast(`Upload error: ${err.message}`);
      isProcessing = false;
    });
  }

  function updateVerticalStepper(stepNum) {
    for (let i = 1; i <= 5; i++) {
      const node = document.getElementById(`vertNode${i}`);
      const desc = document.getElementById(`vertDesc${i}`);
      if (!node || !desc) continue;

      if (i < stepNum) {
        node.className = "vert-node-circ done";
        node.innerHTML = "✓";
        desc.style.color = "var(--success)";
        desc.textContent = "→ Completed";
      } else if (i === stepNum) {
        node.className = "vert-node-circ active";
        node.textContent = i;
        desc.style.color = "var(--cyan)";
        desc.textContent = "→ Processing in real-time...";
      } else {
        node.className = "vert-node-circ";
        node.textContent = i;
        desc.style.color = "var(--text-muted)";
        desc.textContent = "→ Pending";
      }
    }
  }

  /* ==========================================================================
     4. VIEW 2: UPLOAD & PROCESS VIEW
     ========================================================================== */
  function initUploadAndProcessView() {
    const dropZoneLarge = document.getElementById('dropZoneLarge');
    const fileUploadInputLarge = document.getElementById('fileUploadInputLarge');
    const btnBrowseFilesLarge = document.getElementById('btnBrowseFilesLarge');

    if (btnBrowseFilesLarge && fileUploadInputLarge) {
      btnBrowseFilesLarge.addEventListener('click', () => fileUploadInputLarge.click());
    }

    if (fileUploadInputLarge) {
      fileUploadInputLarge.addEventListener('change', (e) => {
        if (e.target.files && e.target.files.length > 0) {
          processUploadedFile(e.target.files[0]);
        }
      });
    }

    if (dropZoneLarge) {
      ['dragenter', 'dragover'].forEach(name => {
        dropZoneLarge.addEventListener(name, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropZoneLarge.style.borderColor = 'var(--cyan)';
          dropZoneLarge.style.background = 'rgba(0, 216, 255, 0.05)';
        });
      });

      ['dragleave', 'drop'].forEach(name => {
        dropZoneLarge.addEventListener(name, (e) => {
          e.preventDefault();
          e.stopPropagation();
          dropZoneLarge.style.borderColor = '';
          dropZoneLarge.style.background = '';
        });
      });

      dropZoneLarge.addEventListener('drop', (e) => {
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          processUploadedFile(e.dataTransfer.files[0]);
        }
      });
    }

    renderRecentFilesTable();
  }

  function renderRecentFilesTable() {
    const tbody = document.getElementById('recentFilesTbody');
    if (!tbody) return;

    let html = '';
    recentFiles.forEach(file => {
      const ext = file.type.toLowerCase();
      html += `<tr>
        <td>
          <div class="table-file-cell">
            <span class="fmt-icon ${ext}">${ext === 'pdf' ? 'PDF' : ext === 'pptx' ? 'P3' : 'Wrd'}</span>
            <span>${escapeHtml(file.name)}</span>
          </div>
        </td>
        <td>${escapeHtml(file.type)}</td>
        <td>${escapeHtml(file.size)}</td>
        <td>${escapeHtml(file.uploaded)}</td>
        <td>
          <span class="badge-status ${file.status}">
            ${file.status === 'completed' ? '✓ Completed' : '● Processing'}
          </span>
        </td>
        <td style="text-align: right;">
          <button class="action-icon-btn" title="Download" onclick="downloadDocumentFile('${file.name}')">⬇</button>
          <button class="action-icon-btn" title="Inspect" onclick="inspectRecentFile('${file.name}')">👁</button>
          <button class="action-icon-btn" title="More">⋮</button>
        </td>
      </tr>`;
    });

    tbody.innerHTML = html;
  }

  window.inspectRecentFile = function (fileName) {
    const rec = historyRecords.find(r => r.name === fileName);
    if (rec && rec.text) {
      loadDocumentToDashboard(rec.name, rec.text);
      switchView('viewDashboard');
      showToast(`Loaded "${fileName}" into Dashboard!`);
    } else {
      switchView('viewDashboard');
      showToast(`Inspecting "${fileName}" in Dashboard.`);
    }
  };

  /* ==========================================================================
     5. VIEW 3: PROCESSING HISTORY VIEW
     ========================================================================== */
  function initHistoryView() {
    const searchInput = document.getElementById('historySearchInput');
    const statusFilter = document.getElementById('historyStatusFilter');

    if (searchInput) {
      searchInput.addEventListener('input', () => {
        renderHistoryTable();
      });
    }

    if (statusFilter) {
      statusFilter.addEventListener('change', () => {
        renderHistoryTable();
      });
    }

    renderHistoryTable();
  }

  function renderHistoryTable() {
    const tbody = document.getElementById('historyTbody');
    if (!tbody) return;

    const searchInput = document.getElementById('historySearchInput');
    const statusFilter = document.getElementById('historyStatusFilter');

    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const status = statusFilter ? statusFilter.value : 'all';

    let filtered = historyRecords.filter(r => {
      const matchQuery = !query || r.name.toLowerCase().includes(query) || r.type.toLowerCase().includes(query);
      const matchStatus = status === 'all' || r.status === status;
      return matchQuery && matchStatus;
    });

    const paginationInfo = document.getElementById('paginationInfo');
    if (paginationInfo) {
      paginationInfo.textContent = `Showing 1 - ${filtered.length} of ${historyRecords.length} files`;
    }

    let html = '';
    filtered.forEach(file => {
      const ext = file.type.toLowerCase();
      html += `<tr>
        <td>
          <div class="table-file-cell">
            <span class="fmt-icon ${ext}">${ext === 'pdf' ? 'PDF' : ext === 'pptx' ? 'P3' : 'Wrd'}</span>
            <span>${escapeHtml(file.name)}</span>
          </div>
        </td>
        <td>${escapeHtml(file.type)}</td>
        <td>${escapeHtml(file.uploaded)}</td>
        <td>
          <span class="badge-status ${file.status}">
            ${file.status === 'completed' ? '✓ Completed' : '✕ Failed'}
          </span>
        </td>
        <td style="font-weight: 700; color: ${file.accuracy.includes('↑') ? 'var(--success)' : '#ffffff'}; font-family: var(--font-mono);">
          ${escapeHtml(file.accuracy)}
        </td>
        <td style="text-align: right;">
          <button class="action-icon-btn" title="Inspect" onclick="loadHistoryRecord('${file.name}')">👁</button>
          <button class="action-icon-btn" title="Download" onclick="downloadDocumentFile('${file.name}')">⬇</button>
          <button class="action-icon-btn" title="More">⋮</button>
        </td>
      </tr>`;
    });

    tbody.innerHTML = html || `<tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--text-muted);">No documents match your filter.</td></tr>`;
  }

  window.loadHistoryRecord = function (fileName) {
    const rec = historyRecords.find(r => r.name === fileName);
    if (rec && rec.text) {
      loadDocumentToDashboard(rec.name, rec.text);
      switchView('viewDashboard');
      showToast(`Loaded "${fileName}" into Live Dashboard.`);
    } else {
      switchView('viewDashboard');
      showToast(`Viewing "${fileName}".`);
    }
  };

  function loadDocumentToDashboard(fileName, rawText) {
    fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: rawText })
    })
    .then(res => res.json())
    .then(analysis => {
      const m1 = analysis.module1_preprocessing || {};
      const m2 = analysis.module2_rule_detection || {};
      const m4 = analysis.module4_hybrid || {};

      const ruleErrors = m2.errors || [];
      const correctedText = m4.final_corrected_text || rawText;
      const totalErrors = m4.total_corrections || ruleErrors.length || 0;

      activeDocument = {
        filename: fileName,
        filesize: `${(rawText.length / 1024).toFixed(1)} KB`,
        uploadTime: "Just now",
        format: fileName.split('.').pop().toLowerCase(),
        originalText: rawText,
        correctedText: correctedText,
        errors: ruleErrors.map((err, i) => ({
          id: i + 1,
          line: Math.min(5, i + 1),
          original: err.matched_text || "error",
          replacement: err.suggested_replacement || "fix",
          rule: err.pattern_id || "Grammar rule",
          desc: err.explanation || "Rule correction"
        })),
        totalErrors: totalErrors,
        qualityScore: Math.min(99, Math.max(88, 100 - totalErrors * 2)),
        words: m1.word_count || rawText.split(/\s+/).length,
        sentences: m1.sentence_count || 3,
        tokens: m1.token_count || rawText.split(/\s+/).length
      };

      renderDashboard(activeDocument);
    })
    .catch(err => console.error(err));
  }

  /* ==========================================================================
     6. VIEW 4: ANALYSIS & INSIGHTS VIEW
     ========================================================================== */
  function initAnalyticsView() {
    const btnExportReport = document.getElementById('btnExportReport');
    if (btnExportReport) {
      btnExportReport.addEventListener('click', () => {
        showToast("📊 Generating executive GrammarGuard AI analytics report...");
        setTimeout(() => {
          const blob = new Blob([
            "GrammarGuard AI - Performance & Accuracy Report\nGenerated: " + new Date().toISOString() +
            "\n\nTotal Documents: 24\nTotal Errors Detected: 186\nCorrections Applied: 172\nOverall Accuracy: 92.4%\nAvg Latency: 42s\nTop Issue: Subject-Verb Agreement (23%)"
          ], { type: "text/plain;charset=utf-8" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = "GrammarGuard_Analytics_Report.txt";
          a.click();
          URL.revokeObjectURL(url);
          showToast("✓ Report downloaded successfully!");
        }, 600);
      });
    }
  }

  /* ==========================================================================
     7. VIEW 5: SETTINGS VIEW
     ========================================================================== */
  function initSettingsView() {
    // Sub-tab buttons
    const tabBtns = document.querySelectorAll('.settings-tab-btn');
    tabBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        tabBtns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const subtab = this.getAttribute('data-subtab');
        showToast(`Settings tab: ${subtab.toUpperCase()} configured.`);
      });
    });

    // Profile update
    const btnUpdateProfile = document.getElementById('btnUpdateProfile');
    if (btnUpdateProfile) {
      btnUpdateProfile.addEventListener('click', () => {
        const name = document.getElementById('settingFullName').value;
        showToast(`✓ Profile updated for ${name}!`);
      });
    }

    // Password update
    const btnUpdatePassword = document.getElementById('btnUpdatePassword');
    if (btnUpdatePassword) {
      btnUpdatePassword.addEventListener('click', () => {
        showToast("✓ Password updated securely!");
      });
    }

    // Region save
    const btnSaveRegion = document.getElementById('btnSaveRegion');
    if (btnSaveRegion) {
      btnSaveRegion.addEventListener('click', () => {
        showToast("✓ Language & region preferences saved!");
      });
    }

    // Password Eye Toggles
    setupPasswordToggle('btnTogglePwCurrent', 'pwCurrent');
    setupPasswordToggle('btnTogglePwNew', 'pwNew');
    setupPasswordToggle('btnTogglePwConfirm', 'pwConfirm');
  }

  function setupPasswordToggle(btnId, inputId) {
    const btn = document.getElementById(btnId);
    const input = document.getElementById(inputId);
    if (btn && input) {
      btn.addEventListener('click', () => {
        if (input.type === 'password') {
          input.type = 'text';
          btn.style.color = 'var(--cyan)';
        } else {
          input.type = 'password';
          btn.style.color = 'var(--text-muted)';
        }
      });
    }
  }

  /* ==========================================================================
     8. MODAL & DOWNLOAD UTILS
     ========================================================================== */
  function initFullDocModal() {
    const btnViewFullDoc = document.getElementById('btnViewFullDoc');
    const fullDocModal = document.getElementById('fullDocModal');
    const btnCloseModal = document.getElementById('btnCloseModal');
    const btnModalCloseAction = document.getElementById('btnModalCloseAction');
    const tabFullComparison = document.getElementById('tabFullComparison');
    const tabLiveEditor = document.getElementById('tabLiveEditor');
    const modalComparisonBody = document.getElementById('modalComparisonBody');
    const modalEditorBody = document.getElementById('modalEditorBody');
    const modalTextarea = document.getElementById('modalTextarea');
    const btnModalAnalyze = document.getElementById('btnModalAnalyze');

    if (btnViewFullDoc && fullDocModal) {
      btnViewFullDoc.addEventListener('click', () => {
        fullDocModal.style.display = 'flex';
        renderModalComparison();
      });
    }

    if (btnCloseModal && fullDocModal) {
      btnCloseModal.addEventListener('click', () => fullDocModal.style.display = 'none');
    }
    if (btnModalCloseAction && fullDocModal) {
      btnModalCloseAction.addEventListener('click', () => fullDocModal.style.display = 'none');
    }

    if (fullDocModal) {
      fullDocModal.addEventListener('click', (e) => {
        if (e.target === fullDocModal) fullDocModal.style.display = 'none';
      });
    }

    if (tabFullComparison && tabLiveEditor) {
      tabFullComparison.addEventListener('click', () => {
        tabFullComparison.classList.add('active');
        tabLiveEditor.classList.remove('active');
        modalComparisonBody.style.display = 'block';
        modalEditorBody.style.display = 'none';
      });

      tabLiveEditor.addEventListener('click', () => {
        tabLiveEditor.classList.add('active');
        tabFullComparison.classList.remove('active');
        modalComparisonBody.style.display = 'none';
        modalEditorBody.style.display = 'block';
        if (modalTextarea && !modalTextarea.value.trim()) {
          modalTextarea.value = activeDocument.originalText;
        }
      });
    }

    if (btnModalAnalyze) {
      btnModalAnalyze.addEventListener('click', () => {
        const text = modalTextarea.value.trim();
        if (!text) {
          showToast("Please enter text to analyze.");
          return;
        }

        btnModalAnalyze.textContent = "Analyzing...";
        fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: text })
        })
        .then(res => res.json())
        .then(analysis => {
          btnModalAnalyze.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> Run Live Pipeline`;
          loadDocumentToDashboard("Interactive_Session.txt", text);
          renderModalComparison();
          showToast("✨ Pipeline executed on custom input!");
        })
        .catch(err => {
          btnModalAnalyze.textContent = "Run Live Pipeline";
          showToast(`Analysis failed: ${err.message}`);
        });
      });
    }
  }

  function renderModalComparison() {
    const modalOriginalLines = document.getElementById('modalOriginalLines');
    const modalCorrectedLines = document.getElementById('modalCorrectedLines');
    const modalDocStats = document.getElementById('modalDocStats');

    if (modalOriginalLines) {
      const lines = activeDocument.originalText.split('\n').filter(l => l.trim().length > 0);
      modalOriginalLines.innerHTML = lines.map((l, i) => `
        <div class="code-line">
          <span class="line-num">${i + 1}</span>
          <span>${escapeHtml(l)}</span>
        </div>
      `).join('');
    }

    if (modalCorrectedLines) {
      const lines = activeDocument.correctedText.split('\n').filter(l => l.trim().length > 0);
      modalCorrectedLines.innerHTML = lines.map((l, i) => `
        <div class="code-line">
          <span class="line-num">${i + 1}</span>
          <span style="color: #6ee7b7;">${escapeHtml(l)}</span>
        </div>
      `).join('');
    }

    if (modalDocStats) {
      modalDocStats.textContent = `${activeDocument.sentences} sentences • ${activeDocument.words} words • ${activeDocument.totalErrors} errors detected`;
    }
  }

  window.downloadDocumentFile = function (fileName, origText, corrText) {
    showToast(`Generating corrected DOCX for "${fileName}"...`);

    const textToUse = corrText || activeDocument.correctedText;
    const baseName = fileName.replace(/\.[^/.]+$/, "");

    fetch('/api/download-corrected', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: origText || activeDocument.originalText,
        corrected_text: textToUse,
        format: "docx",
        filename: baseName
      })
    })
    .then(res => {
      if (!res.ok) throw new Error("Server download failed");
      return res.blob();
    })
    .then(blob => {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${baseName}_corrected.docx`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      showToast(`✓ "${baseName}_corrected.docx" downloaded successfully!`);
    })
    .catch(err => {
      console.warn("Falling back to text file download:", err);
      const blob = new Blob([textToUse], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${baseName}_corrected.txt`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`Downloaded "${baseName}_corrected.txt".`);
    });
  };

  /* ==========================================================================
     9. WEBSOCKET REAL-TIME CONNECTION
     ========================================================================== */
  function initWebSocket() {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/grammar`;
      ws = new WebSocket(wsUrl);

      ws.onopen = function () {
        console.log("[GrammarGuard AI] Real-time WebSocket established.");
      };

      ws.onmessage = function (event) {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'ANALYSIS_UPDATE' && data.payload) {
            console.log("[GrammarGuard AI] Streaming update received.");
          }
        } catch (e) {
          console.error("WS parse error:", e);
        }
      };

      ws.onclose = function () {
        setTimeout(initWebSocket, 5000);
      };
    } catch (e) {
      console.warn("WebSocket fallback to REST API.");
    }
  }

  /* ==========================================================================
     10. TOAST NOTIFICATIONS & UTILS
     ========================================================================== */
  let toastTimer = null;
  function showToast(msg) {
    const toast = document.getElementById('toastNotification');
    const toastMsg = document.getElementById('toastMessage');
    if (!toast || !toastMsg) return;

    toastMsg.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('show');
    }, 3200);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // Self-start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
