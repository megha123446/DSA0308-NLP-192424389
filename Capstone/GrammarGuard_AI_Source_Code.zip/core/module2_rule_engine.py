"""
Module 2: Rule-Based Grammar Error Detection (Advanced Dual-Engine)
Implements deterministic linguistic rule checks across complex syntax,
subject-verb agreement (with intervening clauses), tense consistency,
perfect aspect participles, conditionals, pronoun cases, quantifiers,
double negatives, homophones, and mechanics.
"""

import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict


@dataclass
class RuleViolation:
    id: str
    rule_name: str
    category: str           # Subject-Verb Agreement, Tense & Aspect, Article Usage, Pronoun Case, Quantifier, Double Negative, Homophones, Redundancy, Mechanics
    severity: str           # high, medium, low
    start: int              # start char offset
    end: int                # end char offset
    original: str           # offending text
    replacement: str        # recommended correction
    explanation: str        # grammatical rationale
    pattern_matched: str    # rule pattern signature

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RuleBasedGrammarDetector:
    """Module 2: Scans text using structured linguistic patterns and rules."""

    def __init__(self):
        self._init_rules()

    def _init_rules(self):
        # 1. Base verbs and their 3rd person singular forms
        self.verb_sva_map = {
            "walk": "walks", "go": "goes", "run": "runs", "sleep": "sleeps",
            "play": "plays", "eat": "eats", "see": "sees", "know": "knows",
            "write": "writes", "read": "reads", "speak": "speaks", "like": "likes",
            "want": "wants", "need": "needs", "think": "thinks", "come": "comes",
            "work": "works", "live": "lives", "give": "gives", "take": "takes",
            "help": "helps", "seem": "seems", "feel": "feels", "try": "tries",
            "study": "studies", "carry": "carries", "make": "makes", "do": "does",
            "improve": "improves", "are": "is", "were": "was", "have": "has"
        }
        self.reverse_verb_sva = {v: k for k, v in self.verb_sva_map.items()}

        # 2. Perfect Aspect Participle mapping (has/have/had + past participle)
        self.irregular_participles = {
            "went": "gone", "saw": "seen", "wrote": "written", "took": "taken",
            "came": "come", "broke": "broken", "spoke": "spoken", "ran": "run",
            "did": "done", "became": "become", "chose": "chosen", "ate": "eaten",
            "gave": "given", "knew": "known", "fell": "fallen", "flew": "flown",
            "froze": "frozen", "drank": "drunk", "began": "begun", "swam": "swum"
        }

        # 3. Base form for negative auxiliary verbs (did not + base verb)
        self.past_to_base = {
            "knew": "know", "went": "go", "saw": "see", "spoke": "speak",
            "wrote": "write", "took": "take", "came": "come", "broke": "break",
            "did": "do", "ate": "eat", "gave": "give", "ran": "run"
        }

        # 4. Vowel sound exceptions for Articles ('a' used before vowel letter with /j/ or /w/ sound)
        self.vowel_exceptions_a = {
            "university", "universe", "uniform", "unique", "unit", "user",
            "european", "euphemism", "one", "one-time", "once", "unilateral", "useful"
        }
        # Consonant sound exceptions ('an' used before silent 'h')
        self.consonant_exceptions_an = {
            "hour", "hours", "honest", "honesty", "honor", "honorable", "heir", "heiress"
        }

        # 5. Redundancy / Pleonasm map
        self.redundancy_map = {
            "revert back": "revert",
            "collaborate together": "collaborate",
            "advance warning": "warning",
            "unintentional mistake": "mistake",
            "ATM machine": "ATM",
            "repeat again": "repeat",
            "end result": "result",
            "past history": "history",
            "close proximity": "proximity",
            "free gift": "gift",
            "unexpected surprise": "surprise",
            "join together": "join",
            "reply back": "reply"
        }

    def detect(self, text: str, preprocessed_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Executes comprehensive deterministic linguistic rule checks across the input text.
        """
        violations: List[RuleViolation] = []
        rule_counter = 1

        if not text or not text.strip():
            return []

        # -------------------------------------------------------------
        # 1. COMPLEX SUBJECT-VERB AGREEMENT: INTERVENING PREPOSITIONAL PHRASES
        # e.g., "The box of chocolates are" -> "is", "The quality of these products are" -> "is"
        # -------------------------------------------------------------
        intervening_sva_singular = re.compile(
            r"\b(the|a|an)\s+(box|collection|group|set|series|list|quality|number|pack|pair|leader|bundle)\s+of\s+([a-zA-Z]+)\s+(are|were)\b",
            re.IGNORECASE
        )
        for m in intervening_sva_singular.finditer(text):
            head_noun = m.group(2)
            verb = m.group(4).lower()
            replacement_verb = "is" if verb == "are" else "was"
            violations.append(RuleViolation(
                id=f"ERR-SVA-{rule_counter:03d}",
                rule_name="Complex Subject-Verb Agreement (Intervening Phrase)",
                category="Subject - Verb Agreement",
                severity="high",
                start=m.start(4),
                end=m.end(4),
                original=m.group(4),
                replacement=replacement_verb,
                explanation=f"The singular subject head '{head_noun}' requires the singular verb '{replacement_verb}', not plural '{m.group(4)}' despite intervening plural nouns.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # Plural head with singular verb: "The colors of the rainbow is" -> "are"
        intervening_sva_plural = re.compile(
            r"\b(the|these|those)\s+([a-zA-Z]{3,}s)\s+of\s+(the\s+)?([a-zA-Z]+)\s+(is|was)\b",
            re.IGNORECASE
        )
        for m in intervening_sva_plural.finditer(text):
            head_noun = m.group(2)
            verb = m.group(5).lower()
            replacement_verb = "are" if verb == "is" else "were"
            violations.append(RuleViolation(
                id=f"ERR-SVA-{rule_counter:03d}",
                rule_name="Complex Subject-Verb Agreement (Plural Head)",
                category="Subject - Verb Agreement",
                severity="high",
                start=m.start(5),
                end=m.end(5),
                original=m.group(5),
                replacement=replacement_verb,
                explanation=f"The plural subject head '{head_noun}' requires the plural verb '{replacement_verb}'.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # -------------------------------------------------------------
        # 2. INDEFINITE SINGULAR PRONOUNS (Everyone, Each, Someone, Nobody)
        # e.g., "Everyone have" -> "Everyone has", "Each of the students are" -> "is"
        # -------------------------------------------------------------
        indefinite_pronoun_regex = re.compile(
            r"\b(everyone|everybody|each|anyone|anybody|someone|somebody|nobody|no\s+one)\s+(have|are|were|do)\b",
            re.IGNORECASE
        )
        for m in indefinite_pronoun_regex.finditer(text):
            pronoun = m.group(1)
            verb = m.group(2).lower()
            verb_map = {"have": "has", "are": "is", "were": "was", "do": "does"}
            replacement = verb_map.get(verb, "is")
            violations.append(RuleViolation(
                id=f"ERR-SVA-{rule_counter:03d}",
                rule_name="Indefinite Pronoun Agreement",
                category="Subject - Verb Agreement",
                severity="high",
                start=m.start(2),
                end=m.end(2),
                original=m.group(2),
                replacement=replacement,
                explanation=f"Indefinite pronouns like '{pronoun}' take a singular verb ('{replacement}').",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # "Each of the [plural noun] are/were" -> "is/was"
        each_of_regex = re.compile(
            r"\b(each|neither|either)\s+of\s+(the|these|our)\s+([a-zA-Z]+)\s+(are|were|have)\b",
            re.IGNORECASE
        )
        for m in each_of_regex.finditer(text):
            verb = m.group(4).lower()
            verb_map = {"are": "is", "were": "was", "have": "has"}
            replacement = verb_map.get(verb, "is")
            violations.append(RuleViolation(
                id=f"ERR-SVA-{rule_counter:03d}",
                rule_name="Distributive Pronoun Agreement",
                category="Subject - Verb Agreement",
                severity="high",
                start=m.start(4),
                end=m.end(4),
                original=m.group(4),
                replacement=replacement,
                explanation=f"The distributive pronoun '{m.group(1)}' is singular and requires '{replacement}'.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # -------------------------------------------------------------
        # 3. DIRECT SUBJECT-VERB AGREEMENT: Singular 3rd person & Plural
        # e.g., "She walk" -> "walks", "They was" -> "were", "They goes" -> "go"
        # -------------------------------------------------------------
        sva_direct_regex = re.compile(
            r"\b(he|she|it|the\s+teacher|the\s+student|the\s+child|the\s+man|the\s+woman)\s+([a-zA-Z]+)\b",
            re.IGNORECASE
        )
        has_past_indicator = bool(re.search(r"\b(yesterday|last\s+(?:week|month|year|night)|in\s+\d{4}|ago)\b", text, re.IGNORECASE))
        for m in sva_direct_regex.finditer(text):
            verb_candidate = m.group(2).lower()
            if has_past_indicator and verb_candidate in {"go", "see", "come", "take", "write", "walk", "run"}:
                continue
            if verb_candidate in self.verb_sva_map:
                corrected_verb = self.verb_sva_map[verb_candidate]
                if m.group(2)[0].isupper():
                    corrected_verb = corrected_verb.capitalize()
                violations.append(RuleViolation(
                    id=f"ERR-SVA-{rule_counter:03d}",
                    rule_name="Subject-Verb Agreement (Singular 3rd Person)",
                    category="Subject - Verb Agreement",
                    severity="high",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement=corrected_verb,
                    explanation=f"Third-person singular subject '{m.group(1)}' requires the singular verb form '{corrected_verb}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # Plural subject with singular verb: "They was" -> "were", "They goes" -> "go"
        plural_sva_regex = re.compile(
            r"\b(they|we)\s+([a-zA-Z]+)\b",
            re.IGNORECASE
        )
        for m in plural_sva_regex.finditer(text):
            verb_candidate = m.group(2).lower()
            if verb_candidate == "was":
                violations.append(RuleViolation(
                    id=f"ERR-SVA-{rule_counter:03d}",
                    rule_name="Subject-Verb Agreement (Plural Past 'was')",
                    category="Subject - Verb Agreement",
                    severity="high",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement="were",
                    explanation=f"Plural pronoun '{m.group(1)}' requires the plural past verb 'were', not 'was'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1
            elif verb_candidate in self.reverse_verb_sva:
                base_verb = self.reverse_verb_sva[verb_candidate]
                violations.append(RuleViolation(
                    id=f"ERR-SVA-{rule_counter:03d}",
                    rule_name="Subject-Verb Agreement (Plural with -s Verb)",
                    category="Subject - Verb Agreement",
                    severity="high",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement=base_verb,
                    explanation=f"Plural pronoun '{m.group(1)}' requires the base plural verb form '{base_verb}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 3B. INFINITIVE VERB FORM ERRORS (to + 3rd person singular verb)
        # e.g., "to improves" -> "to improve", "to goes" -> "to go"
        # -------------------------------------------------------------
        infinitive_err_regex = re.compile(r"\bto\s+([a-zA-Z]+s)\b", re.IGNORECASE)
        for m in infinitive_err_regex.finditer(text):
            v = m.group(1).lower()
            if v in self.reverse_verb_sva:
                base_v = self.reverse_verb_sva[v]
                violations.append(RuleViolation(
                    id=f"ERR-INF-{rule_counter:03d}",
                    rule_name="Infinitive Verb Form Error",
                    category="Verb Form",
                    severity="high",
                    start=m.start(1),
                    end=m.end(1),
                    original=m.group(1),
                    replacement=base_v,
                    explanation=f"Infinitive marker 'to' must be followed by base form '{base_v}', not inflected '{m.group(1)}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 3C. GERUND USAGE IN PREPOSITIONAL IDIOMS
        # e.g., "looking forward to see" -> "looking forward to seeing"
        # -------------------------------------------------------------
        gerund_idiom_regex = re.compile(r"\b(look(?:ing)?\s+forward\s+to)\s+([a-zA-Z]+)\b", re.IGNORECASE)
        for m in gerund_idiom_regex.finditer(text):
            verb = m.group(2).lower()
            if verb in ["see", "hear", "meet", "receive", "work", "visit", "read"]:
                gerund = verb + "ing" if not verb.endswith("e") else verb[:-1] + "ing"
                violations.append(RuleViolation(
                    id=f"ERR-GER-{rule_counter:03d}",
                    rule_name="Gerund Usage in Prepositional Idiom",
                    category="Verb Form",
                    severity="medium",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement=gerund,
                    explanation=f"The idiom '{m.group(1)}' requires a gerund ('{gerund}'), not base form '{m.group(2)}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 3D. PAST TEMPORAL MARKER WITH PRESENT BASE VERB
        # e.g., "She go to the market yesterday" -> "went"
        # -------------------------------------------------------------
        past_temporal_regex = re.compile(r"\b(yesterday|last\s+(?:week|month|year|night)|in\s+\d{4}|ago)\b", re.IGNORECASE)
        if past_temporal_regex.search(text):
            simple_past_err = re.compile(r"\b(she|he|they|we|i|the\s+student)\s+(go|see|come|take|write)\b", re.IGNORECASE)
            past_map = {"go": "went", "see": "saw", "come": "came", "take": "took", "write": "wrote"}
            for m in simple_past_err.finditer(text):
                base_v = m.group(2).lower()
                if base_v in past_map:
                    past_v = past_map[base_v]
                    violations.append(RuleViolation(
                        id=f"ERR-TNS-{rule_counter:03d}",
                        rule_name="Incorrect Past Verb Tense",
                        category="Tense & Aspect",
                        severity="high",
                        start=m.start(2),
                        end=m.end(2),
                        original=m.group(2),
                        replacement=past_v,
                        explanation=f"A past temporal indicator requires the past tense '{past_v}', not present base '{m.group(2)}'.",
                        pattern_matched=m.group()
                    ))
                    rule_counter += 1

        # -------------------------------------------------------------
        # 4. PERFECT ASPECT PARTICIPLE ERRORS
        # e.g., "has went" -> "has gone", "have saw" -> "have seen", "had wrote" -> "had written"
        # -------------------------------------------------------------
        perfect_aspect_regex = re.compile(
            r"\b(has|have|had)\s+([a-zA-Z]+)\b",
            re.IGNORECASE
        )
        for m in perfect_aspect_regex.finditer(text):
            verb_form = m.group(2).lower()
            if verb_form in self.irregular_participles:
                corrected_participle = self.irregular_participles[verb_form]
                violations.append(RuleViolation(
                    id=f"ERR-TNS-{rule_counter:03d}",
                    rule_name="Past Participle in Perfect Aspect",
                    category="Tense & Aspect",
                    severity="high",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement=corrected_participle,
                    explanation=f"The auxiliary '{m.group(1)}' requires the past participle form '{corrected_participle}', not the simple past '{m.group(2)}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 5. NEGATIVE & MODAL AUXILIARY VERB BASE FORM
        # e.g., "did not knew" -> "know", "will went" -> "go", "will not does" -> "do"
        # -------------------------------------------------------------
        did_not_regex = re.compile(
            r"\b(did\s+not|didn't)\s+([a-zA-Z]+)\b",
            re.IGNORECASE
        )
        for m in did_not_regex.finditer(text):
            verb_candidate = m.group(2).lower()
            if verb_candidate in self.past_to_base:
                base_verb = self.past_to_base[verb_candidate]
                violations.append(RuleViolation(
                    id=f"ERR-TNS-{rule_counter:03d}",
                    rule_name="Auxiliary 'did not' Base Verb Form",
                    category="Tense & Aspect",
                    severity="high",
                    start=m.start(2),
                    end=m.end(2),
                    original=m.group(2),
                    replacement=base_verb,
                    explanation=f"The auxiliary verb '{m.group(1)}' must be followed by the base verb form '{base_verb}', not past tense '{m.group(2)}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        modal_regex = re.compile(
            r"\b(will|can|could|would|should|might|must|shall)\s+(went|walked|bought|came|saw|did|had|took|ate)\b",
            re.IGNORECASE
        )
        modal_base_map = {
            "went": "go", "walked": "walk", "bought": "buy", "came": "come",
            "saw": "see", "did": "do", "had": "have", "took": "take", "ate": "eat"
        }
        for m in modal_regex.finditer(text):
            past_verb = m.group(2).lower()
            base_form = modal_base_map.get(past_verb, "go")
            violations.append(RuleViolation(
                id=f"ERR-TNS-{rule_counter:03d}",
                rule_name="Modal Verb followed by Past Tense",
                category="Tense & Aspect",
                severity="high",
                start=m.start(2),
                end=m.end(2),
                original=m.group(2),
                replacement=base_form,
                explanation=f"Modal verbs ('{m.group(1)}') must be followed by a base form verb ('{base_form}'), not past tense '{past_verb}'.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # -------------------------------------------------------------
        # 6. COMPLEX CONDITIONALS (Counterfactual shift)
        # e.g., "If I would have known" -> "If I had known"
        # -------------------------------------------------------------
        conditional_regex = re.compile(
            r"\b(if\s+(?:i|he|she|they|we|you))\s+would\s+have\s+([a-zA-Z]+)\b",
            re.IGNORECASE
        )
        for m in conditional_regex.finditer(text):
            subject_phrase = m.group(1)
            verb = m.group(2)
            violations.append(RuleViolation(
                id=f"ERR-TNS-{rule_counter:03d}",
                rule_name="Conditional Past Counterfactual (would have -> had)",
                category="Tense & Aspect",
                severity="high",
                start=m.start(),
                end=m.end(),
                original=m.group(),
                replacement=f"{subject_phrase} had {verb}",
                explanation="In the 'if' clause of a past conditional sentence, use the past perfect ('had + participle'), not 'would have'.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # -------------------------------------------------------------
        # 7. ARTICLES & PHONETIC RULES (a vs. an, vowel sounds & silent h)
        # e.g., "an book" -> "a book", "a hour" -> "an hour", "an university" -> "a university"
        # -------------------------------------------------------------
        article_regex = re.compile(r"\b(a|an)\s+([a-zA-Z]+)\b", re.IGNORECASE)
        for m in article_regex.finditer(text):
            art = m.group(1).lower()
            next_word = m.group(2).lower()
            first_letter = next_word[0]

            # Case A: Used 'a' before vowel letter, but check if exception applies
            if art == "a":
                if first_letter in "aeiou":
                    if next_word not in self.vowel_exceptions_a:
                        violations.append(RuleViolation(
                            id=f"ERR-ART-{rule_counter:03d}",
                            rule_name="Indefinite Article 'a' before Vowel Sound",
                            category="Article",
                            severity="medium",
                            start=m.start(1),
                            end=m.end(1),
                            original=m.group(1),
                            replacement="an" if m.group(1).islower() else "An",
                            explanation=f"Use 'an' before words beginning with a vowel sound ('{next_word}').",
                            pattern_matched=m.group()
                        ))
                        rule_counter += 1
                elif next_word in self.consonant_exceptions_an:
                    violations.append(RuleViolation(
                        id=f"ERR-ART-{rule_counter:03d}",
                        rule_name="Indefinite Article 'a' before Silent 'h'",
                        category="Article",
                        severity="medium",
                        start=m.start(1),
                        end=m.end(1),
                        original=m.group(1),
                        replacement="an" if m.group(1).islower() else "An",
                        explanation=f"'{next_word}' begins with a silent 'h' and vowel sound, requiring 'an'.",
                        pattern_matched=m.group()
                    ))
                    rule_counter += 1

            # Case B: Used 'an' before consonant letter, but check if vowel exception applies
            elif art == "an":
                if first_letter not in "aeiou":
                    if next_word not in self.consonant_exceptions_an:
                        violations.append(RuleViolation(
                            id=f"ERR-ART-{rule_counter:03d}",
                            rule_name="Indefinite Article 'an' before Consonant Sound",
                            category="Article",
                            severity="medium",
                            start=m.start(1),
                            end=m.end(1),
                            original=m.group(1),
                            replacement="a" if m.group(1).islower() else "A",
                            explanation=f"Use 'a' before words beginning with a consonant sound ('{next_word}').",
                            pattern_matched=m.group()
                        ))
                        rule_counter += 1
                elif next_word in self.vowel_exceptions_a:
                    violations.append(RuleViolation(
                        id=f"ERR-ART-{rule_counter:03d}",
                        rule_name="Indefinite Article 'an' before Consonant Sound (e.g. /ju:/)",
                        category="Article",
                        severity="medium",
                        start=m.start(1),
                        end=m.end(1),
                        original=m.group(1),
                        replacement="a" if m.group(1).islower() else "A",
                        explanation=f"'{next_word}' begins with a consonant sound (/j/), requiring 'a' instead of 'an'.",
                        pattern_matched=m.group()
                    ))
                    rule_counter += 1

        # Redundant Determiners: "the the" -> "the", "a a" -> "a"
        redundant_det_regex = re.compile(r"\b(the|a|an)\s+\1\b", re.IGNORECASE)
        for m in redundant_det_regex.finditer(text):
            word = m.group(1)
            violations.append(RuleViolation(
                id=f"ERR-ART-{rule_counter:03d}",
                rule_name="Duplicate Determiner",
                category="Article",
                severity="medium",
                start=m.start(),
                end=m.end(),
                original=m.group(),
                replacement=word,
                explanation=f"Duplicate consecutive article '{m.group()}'.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # -------------------------------------------------------------
        # 8. COUNT VS NON-COUNT QUANTIFIERS
        # e.g., "much books" -> "many books", "less people" -> "fewer people"
        # -------------------------------------------------------------
        quantifier_rules = [
            (r"\bmuch\s+(books|people|students|cars|computers|items|problems|questions|options)\b", "many", "Countable Quantifier", "Use 'many' with countable plural nouns."),
            (r"\bmany\s+(water|information|furniture|advice|equipment|homework|luggage|money)\b", "much", "Uncountable Quantifier", "Use 'much' with uncountable mass nouns."),
            (r"\bless\s+(people|books|items|students|cars|errors|words|hours)\b", "fewer", "Countable Comparative", "Use 'fewer' for countable items and 'less' for uncountable quantities."),
            (r"\bfewer\s+(water|time|money|information|work|effort|sugar)\b", "less", "Uncountable Comparative", "Use 'less' for uncountable mass nouns.")
        ]
        for pattern, repl_word, rname, rdesc in quantifier_rules:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                # Replace the quantifier word only
                first_word = m.group(0).split()[0]
                violations.append(RuleViolation(
                    id=f"ERR-QNT-{rule_counter:03d}",
                    rule_name=rname,
                    category="Quantifier Usage",
                    severity="medium",
                    start=m.start(),
                    end=m.start() + len(first_word),
                    original=first_word,
                    replacement=repl_word if first_word.islower() else repl_word.capitalize(),
                    explanation=rdesc,
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 9. PRONOUN CASE & AGREEMENT
        # e.g., "Between you and I" -> "Between you and me", "Him and me went" -> "He and I went"
        # -------------------------------------------------------------
        pronoun_rules = [
            (r"\bbetween\s+(you\s+and\s+i)\b", "you and me", "Pronoun Case (Prepositional Object)", "Prepositions like 'between' take object pronouns ('me', not 'I')."),
            (r"\b(for|with|to)\s+(him\s+and\s+i|her\s+and\s+i)\b", lambda m: f"{m.group(1)} {m.group(2).replace(' and i', ' and me')}", "Pronoun Case (Object)", "Use objective case pronouns ('me') following prepositions."),
            (r"\b(him|her|them)\s+and\s+(me|i)\s+(went|are|were|will|have|had|is|was)\b", "He and I", "Pronoun Case (Compound Subject)", "Use subjective case pronouns ('He and I') as sentence subjects."),
            (r"\bto\s+(who)\b", "whom", "Pronoun Case (Preposition + Whom)", "Use 'whom' as the object of a preposition ('to whom').")
        ]
        for pattern, repl, rname, rdesc in pronoun_rules:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                if callable(repl):
                    rep_str = repl(m)
                    start, end, orig = m.start(), m.end(), m.group()
                elif rname == "Pronoun Case (Preposition + Whom)":
                    rep_str = repl
                    start, end, orig = m.start(1), m.end(1), m.group(1)
                elif rname == "Pronoun Case (Prepositional Object)":
                    rep_str = repl
                    start, end, orig = m.start(1), m.end(1), m.group(1)
                else:
                    rep_str = repl
                    start, end, orig = m.start(), m.end(), m.group()

                violations.append(RuleViolation(
                    id=f"ERR-PRN-{rule_counter:03d}",
                    rule_name=rname,
                    category="Pronoun Case",
                    severity="medium",
                    start=start,
                    end=end,
                    original=orig,
                    replacement=rep_str,
                    explanation=rdesc,
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 10. DOUBLE NEGATIVES
        # e.g., "don't know nothing" -> "don't know anything", "can't hardly" -> "can hardly"
        # -------------------------------------------------------------
        double_neg_rules = [
            (r"\b(don't|doesn't|didn't)\s+([a-zA-Z]+\s+)?(nothing)\b", 3, "anything", "Double Negative", "Use 'anything' instead of 'nothing' with negative verbs."),
            (r"\b(don't|doesn't|didn't)\s+([a-zA-Z]+\s+)?(nobody|no\s+one)\b", 3, "anybody", "Double Negative", "Use 'anybody' or 'anyone' with negative verbs."),
            (r"\b(can't|cannot)\s+(hardly)\b", 0, "can hardly", "Double Negative with 'hardly'", "'Hardly' already carries negative meaning; pair with 'can' rather than 'cannot'.")
        ]
        for pattern, grp_idx, repl_str, rname, rdesc in double_neg_rules:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                if grp_idx == 0:
                    start, end, orig = m.start(), m.end(), m.group()
                else:
                    start, end, orig = m.start(grp_idx), m.end(grp_idx), m.group(grp_idx)
                violations.append(RuleViolation(
                    id=f"ERR-NEG-{rule_counter:03d}",
                    rule_name=rname,
                    category="Double Negative",
                    severity="high",
                    start=start,
                    end=end,
                    original=orig,
                    replacement=repl_str,
                    explanation=rdesc,
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 11. HOMOPHONES & CONFUSABLES
        # e.g., affect/effect, their/there/they're, its/it's, your/you're, then/than
        # -------------------------------------------------------------
        homophone_patterns = [
            (r"\b(their)\s+(is|are|was|were|going|coming|leaving|doing|having)\b", 1, "they're", "Homophones", "Use 'they're' (contraction of 'they are') before verbs, not the possessive 'their'."),
            (r"\b(over|in|at)\s+(their)\b", 2, "there", "Homophones", "Use 'there' to refer to a place, not the possessive 'their'."),
            (r"\b(your)\s+(welcome|right|wrong|going|doing|invited|ready)\b", 1, "you're", "Homophones", "Use 'you're' (you are) when describing an action or state."),
            (r"\b(its)\s+(a|an|the|very|not|going|raining|been|time|okay|clear|important)\b", 1, "it's", "Homophones", "Use 'it's' (it is / it has) before articles, adjectives, or participles."),
            (r"\b(better|more|less|worse|larger|smaller|faster|slower|older|younger|rather)\s+(then)\b", 2, "than", "Homophones", "Use 'than' for comparisons. 'Then' refers to time sequences."),
            (r"\b(side|cause\s+and|adverse|take)\s+(affects?)\b", 2, "effects", "Confusables", "Use 'effect' as a noun meaning result or outcome."),
            (r"\b(will|can|could|would|to)\s+(effects?)\b", 2, "affect", "Confusables", "Use 'affect' as a verb meaning to influence."),
            (r"\b(don't|will|to|might|could)\s+(loose)\b", 2, "lose", "Confusables", "Use 'lose' (verb: misplace). 'Loose' is an adjective (not tight)."),
            (r"\b(school|high\s+school)\s+(principle)\b", 2, "principal", "Confusables", "A school head is a 'principal'. A 'principle' is a fundamental rule."),
            (r"\b(matter\s+of)\s+(principal)\b", 2, "principle", "Confusables", "Use 'principle' when referring to a fundamental belief or moral code.")
        ]
        for pattern, grp_idx, repl_str, rcat, rdesc in homophone_patterns:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                violations.append(RuleViolation(
                    id=f"ERR-HOM-{rule_counter:03d}",
                    rule_name=f"Confusable / Homophone ({repl_str})",
                    category=rcat,
                    severity="high",
                    start=m.start(grp_idx),
                    end=m.end(grp_idx),
                    original=m.group(grp_idx),
                    replacement=repl_str if m.group(grp_idx).islower() else repl_str.capitalize(),
                    explanation=rdesc,
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 12. REDUNDANCIES & PLEONASMS
        # e.g., "revert back" -> "revert", "collaborate together" -> "collaborate"
        # -------------------------------------------------------------
        for phrase, repl in self.redundancy_map.items():
            pattern = rf"\b{re.escape(phrase)}\b"
            for m in re.finditer(pattern, text, re.IGNORECASE):
                violations.append(RuleViolation(
                    id=f"ERR-RED-{rule_counter:03d}",
                    rule_name="Redundant Expression / Pleonasm",
                    category="Redundancy",
                    severity="low",
                    start=m.start(),
                    end=m.end(),
                    original=m.group(),
                    replacement=repl if m.group().islower() else repl.capitalize(),
                    explanation=f"'{m.group()}' is redundant. Simplify to '{repl}'.",
                    pattern_matched=m.group()
                ))
                rule_counter += 1

        # -------------------------------------------------------------
        # 13. MECHANICS & PUNCTUATION
        # e.g., "word , " -> "word,", missing comma before coordinating conjunctions
        # -------------------------------------------------------------
        space_punct_regex = re.compile(r"(\w+)\s+([,.;:?!])")
        for m in space_punct_regex.finditer(text):
            violations.append(RuleViolation(
                id=f"ERR-MEC-{rule_counter:03d}",
                rule_name="Spacing Before Punctuation",
                category="Punctuation",
                severity="low",
                start=m.start(),
                end=m.end(),
                original=m.group(),
                replacement=f"{m.group(1)}{m.group(2)}",
                explanation="Punctuation marks should immediately follow the preceding word without an intervening space.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # Missing comma before coordinating conjunction: "good so they" -> "good, so they"
        comma_conj_regex = re.compile(r"\b([a-zA-Z]{2,})(\s+)(so|but)\s+(they|we|he|she|it|i|you)\b", re.IGNORECASE)
        for m in comma_conj_regex.finditer(text):
            conj = m.group(3)
            violations.append(RuleViolation(
                id=f"ERR-PUN-{rule_counter:03d}",
                rule_name="Missing Comma Before Coordinating Conjunction",
                category="Punctuation",
                severity="medium",
                start=m.start(2),
                end=m.end(3),
                original=text[m.start(2):m.end(3)],
                replacement=f", {conj}",
                explanation=f"Use a comma before '{conj}' when joining independent clauses.",
                pattern_matched=m.group()
            ))
            rule_counter += 1

        # Sort violations by start position
        violations.sort(key=lambda v: (v.start, v.end))
        return [v.to_dict() for v in violations]


if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from core.module1_preprocessing import TextPreprocessor

    test_sentence = (
        "The box of chocolates are on the table. Everyone have finished their work. "
        "She has went home early and will went again tomorrow. "
        "Between you and I, I don't have no money for less people."
    )
    preprocessor = TextPreprocessor()
    preprocessed = preprocessor.process(test_sentence)

    detector = RuleBasedGrammarDetector()
    violations = detector.detect(test_sentence, preprocessed)

    print(f"Detected {len(violations)} complex rule violations:")
    for v in violations:
        print(f"- [{v['category']}] '{v['original']}' -> '{v['replacement']}': {v['explanation']}")
