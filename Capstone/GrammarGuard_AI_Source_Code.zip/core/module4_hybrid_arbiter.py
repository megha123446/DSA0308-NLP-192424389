"""
Module 4: Hybrid Integration & Error Resolution
Fuses Rule-Based Detection (Module 2) and Transformer Correction (Module 3)
through spatial collision detection, confidence arbitration, and diff synthesis.
"""

from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict


@dataclass
class ResolvedEdit:
    edit_id: str
    start: int
    end: int
    original: str
    replacement: str
    source: str                 # "RULE", "TRANSFORMER", "AGREEMENT", "HYBRID_ARBITRATED"
    confidence: float           # 0.0 to 1.0
    category: str
    explanation: str
    arbitration_reason: str     # Rationale for why this resolution was chosen
    rule_id: str = ""
    transformer_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DiffChunk:
    type: str                   # "unchanged", "removed", "added"
    text: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class HybridErrorResolver:
    """
    Module 4: Intelligent Hybrid Arbiter.
    Merges deterministic rule outputs and probabilistic transformer predictions.
    """

    def __init__(self):
        pass

    def check_overlap(self, start1: int, end1: int, start2: int, end2: int) -> bool:
        """Determines if two character spans overlap."""
        return max(start1, start2) < min(end1, end2)

    def resolve(self, text: str, rule_errors: List[Dict[str, Any]], transformer_suggestions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Executes Module 4 arbitration workflow:
        1. Spatial collision matching
        2. Priority arbitration based on linguistic certainty & confidence
        3. Reconstruction of the final corrected text
        4. Unified diff generation
        5. Arbitration audit report
        """
        resolved_edits: List[ResolvedEdit] = []
        arbitration_logs: List[Dict[str, Any]] = []
        edit_counter = 1

        matched_transformer_ids = set()
        matched_rule_ids = set()

        # Step 1: Detect collisions and agreements between Rule and Transformer
        for r_err in rule_errors:
            r_start, r_end = r_err["start"], r_err["end"]
            r_orig = r_err["original"]
            r_rep = r_err["replacement"]
            r_cat = r_err["category"]
            r_id = r_err["id"]

            overlapping_trf = []
            for t_sug in transformer_suggestions:
                t_start, t_end = t_sug["start"], t_sug["end"]
                if self.check_overlap(r_start, r_end, t_start, t_end):
                    overlapping_trf.append(t_sug)

            if not overlapping_trf:
                # Rule-only detection (high deterministic precision)
                resolved_edits.append(ResolvedEdit(
                    edit_id=f"HYB-{edit_counter:03d}",
                    start=r_start,
                    end=r_end,
                    original=r_orig,
                    replacement=r_rep,
                    source="RULE",
                    confidence=0.96,
                    category=r_cat,
                    explanation=r_err["explanation"],
                    arbitration_reason="Deterministic grammatical rule identified clear structural violation.",
                    rule_id=r_id
                ))
                matched_rule_ids.add(r_id)
                arbitration_logs.append({
                    "span": f"[{r_start}:{r_end}]",
                    "conflict": False,
                    "resolution": "Adopted Rule Engine Output",
                    "rule_suggestion": r_rep,
                    "transformer_suggestion": None,
                    "rationale": "High precision rule triggered without transformer ambiguity."
                })
                edit_counter += 1
            else:
                # Collision detected: arbitrate between rule and transformer
                best_trf = overlapping_trf[0]
                t_id = best_trf["id"]
                t_rep = best_trf["replacement"]
                t_conf = best_trf.get("confidence", 0.90)
                matched_rule_ids.add(r_id)
                matched_transformer_ids.add(t_id)

                if r_rep.strip().lower() == t_rep.strip().lower():
                    # Unanimous agreement!
                    resolved_edits.append(ResolvedEdit(
                        edit_id=f"HYB-{edit_counter:03d}",
                        start=min(r_start, best_trf["start"]),
                        end=max(r_end, best_trf["end"]),
                        original=text[min(r_start, best_trf["start"]):max(r_end, best_trf["end"])],
                        replacement=r_rep,
                        source="AGREEMENT",
                        confidence=0.99,
                        category=r_cat,
                        explanation=f"{r_err['explanation']} (Confirmed by Transformer context).",
                        arbitration_reason="Dual consensus: Rule Engine and Neural Transformer converged on identical correction.",
                        rule_id=r_id,
                        transformer_id=t_id
                    ))
                    arbitration_logs.append({
                        "span": f"[{r_start}:{r_end}]",
                        "conflict": False,
                        "resolution": "Consensus Agreement",
                        "rule_suggestion": r_rep,
                        "transformer_suggestion": t_rep,
                        "rationale": "Perfect consensus across deterministic and neural layers (confidence: 99%)."
                    })
                else:
                    # Conflicting replacements: evaluate linguistic tier
                    # Strict grammar rules (SVA, Article 'a/an') take precedence over loose transformer rewrites
                    if r_cat in {"Subject-Verb Agreement", "Article Usage"}:
                        chosen_rep = r_rep
                        chosen_source = "HYBRID_ARBITRATED"
                        reason = f"Deterministic rule prioritized for structural syntax violation ({r_cat})."
                    else:
                        # Contextual/fluency preferred from transformer if confidence is high
                        chosen_rep = t_rep if t_conf >= 0.92 else r_rep
                        chosen_source = "HYBRID_ARBITRATED"
                        reason = f"Transformer favored due to superior semantic fluency confidence ({t_conf:.2f})."

                    resolved_edits.append(ResolvedEdit(
                        edit_id=f"HYB-{edit_counter:03d}",
                        start=min(r_start, best_trf["start"]),
                        end=max(r_end, best_trf["end"]),
                        original=text[min(r_start, best_trf["start"]):max(r_end, best_trf["end"])],
                        replacement=chosen_rep,
                        source=chosen_source,
                        confidence=max(0.92, t_conf),
                        category=r_cat,
                        explanation=f"Arbitrated correction: {r_err['explanation']}",
                        arbitration_reason=reason,
                        rule_id=r_id,
                        transformer_id=t_id
                    ))
                    arbitration_logs.append({
                        "span": f"[{r_start}:{r_end}]",
                        "conflict": True,
                        "resolution": f"Arbitrated to: '{chosen_rep}'",
                        "rule_suggestion": r_rep,
                        "transformer_suggestion": t_rep,
                        "rationale": reason
                    })
                edit_counter += 1

        # Step 2: Add remaining Transformer-only suggestions (collocations, idiomatic phrasing)
        for t_sug in transformer_suggestions:
            if t_sug["id"] not in matched_transformer_ids:
                # Check for overlaps with already resolved edits
                t_start, t_end = t_sug["start"], t_sug["end"]
                overlaps = any(self.check_overlap(t_start, t_end, res.start, res.end) for res in resolved_edits)
                if not overlaps:
                    resolved_edits.append(ResolvedEdit(
                        edit_id=f"HYB-{edit_counter:03d}",
                        start=t_start,
                        end=t_end,
                        original=t_sug["original"],
                        replacement=t_sug["replacement"],
                        source="TRANSFORMER",
                        confidence=t_sug.get("confidence", 0.90),
                        category=f"Fluency ({t_sug.get('type', 'Contextual')})",
                        explanation=t_sug["explanation"],
                        arbitration_reason="Neural Transformer captured semantic collocation outside rigid rule scope.",
                        transformer_id=t_sug["id"]
                    ))
                    arbitration_logs.append({
                        "span": f"[{t_start}:{t_end}]",
                        "conflict": False,
                        "resolution": "Adopted Transformer Neural Output",
                        "rule_suggestion": None,
                        "transformer_suggestion": t_sug["replacement"],
                        "rationale": "High-confidence neural suggestion for contextual fluency."
                    })
                    edit_counter += 1

        # Sort resolved edits by start position
        resolved_edits.sort(key=lambda e: (e.start, e.end))

        # Step 3: Reconstruct Final Corrected Text without character offset corruption
        # Reconstruct by splicing from left to right
        corrected_parts = []
        diff_chunks: List[DiffChunk] = []
        curr_idx = 0

        for edit in resolved_edits:
            if edit.start < curr_idx:
                # Discard overlapping edit collision
                continue

            if edit.start > curr_idx:
                unchanged_segment = text[curr_idx:edit.start]
                corrected_parts.append(unchanged_segment)
                diff_chunks.append(DiffChunk(type="unchanged", text=unchanged_segment))

            # Add diff removal and addition
            diff_chunks.append(DiffChunk(type="removed", text=text[edit.start:edit.end]))
            diff_chunks.append(DiffChunk(type="added", text=edit.replacement))
            corrected_parts.append(edit.replacement)

            curr_idx = edit.end

        if curr_idx < len(text):
            trailing = text[curr_idx:]
            corrected_parts.append(trailing)
            diff_chunks.append(DiffChunk(type="unchanged", text=trailing))

        final_corrected_text = "".join(corrected_parts)

        # Step 4: Hybrid metrics
        total_edits = len(resolved_edits)
        rule_count = sum(1 for e in resolved_edits if e.source in {"RULE", "AGREEMENT"})
        trf_count = sum(1 for e in resolved_edits if e.source in {"TRANSFORMER", "AGREEMENT"})
        agreement_count = sum(1 for e in resolved_edits if e.source == "AGREEMENT")
        arbitrated_count = sum(1 for e in resolved_edits if e.source == "HYBRID_ARBITRATED")

        rule_contribution_pct = round((rule_count / max(1, total_edits)) * 100, 1)
        trf_contribution_pct = round((trf_count / max(1, total_edits)) * 100, 1)
        agreement_pct = round((agreement_count / max(1, total_edits)) * 100, 1)

        avg_confidence = round(
            sum(e.confidence for e in resolved_edits) / max(1, total_edits), 3
        ) if total_edits > 0 else 1.0

        return {
            "final_corrected_text": final_corrected_text,
            "resolved_edits": [e.to_dict() for e in resolved_edits],
            "diff_chunks": [d.to_dict() for d in diff_chunks],
            "arbitration_audit": arbitration_logs,
            "metrics": {
                "total_resolved_errors": total_edits,
                "rule_contribution_pct": rule_contribution_pct,
                "transformer_contribution_pct": trf_contribution_pct,
                "agreement_rate_pct": agreement_pct,
                "arbitrated_conflicts_count": arbitrated_count,
                "average_ensemble_confidence": avg_confidence
            }
        }


if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from core.module1_preprocessing import TextPreprocessor
    from core.module2_rule_engine import RuleBasedGrammarDetector
    from core.module3_transformer import TransformerGrammarCorrector

    print("=" * 70)
    print(" MODULE 4: HYBRID INTEGRATION & ERROR RESOLUTION (STANDALONE RUNNER)")
    print(" Spatial Collision Detection, Confidence Arbitration & Text Reconstruction")
    print("=" * 70)

    sample_text = "She walk to library and bought an book. He was interested about learning, but will went home early."
    print(f"\n[Input Text]: \"{sample_text}\"\n")

    # Run Module 1
    preprocessor = TextPreprocessor()
    preprocessed = preprocessor.process(sample_text)

    # Run Module 2
    rule_detector = RuleBasedGrammarDetector()
    rule_errors = rule_detector.detect(sample_text, preprocessed)

    # Run Module 3
    trf_corrector = TransformerGrammarCorrector()
    trf_result = trf_corrector.correct(sample_text, preprocessed)

    # Run Module 4
    arbiter = HybridErrorResolver()
    hybrid_result = arbiter.resolve(
        text=sample_text,
        rule_errors=rule_errors,
        transformer_suggestions=trf_result["suggestions"]
    )

    print(f"[Resolved Final Corrected Text]:\n  \"{hybrid_result['final_corrected_text']}\"\n")
    print(f"[Ensemble Metrics]:")
    print(f"  * Total Resolved Edits:          {hybrid_result['metrics']['total_resolved_errors']}")
    print(f"  * Rule Engine Contribution:      {hybrid_result['metrics']['rule_contribution_pct']}%")
    print(f"  * Transformer Contribution:      {hybrid_result['metrics']['transformer_contribution_pct']}%")
    print(f"  * Algorithm Consensus Rate:      {hybrid_result['metrics']['agreement_rate_pct']}%")
    print(f"  * Arbitrated Conflicts Count:    {hybrid_result['metrics']['arbitrated_conflicts_count']}")
    print(f"  * Average Ensemble Confidence:   {hybrid_result['metrics']['average_ensemble_confidence']}")

    print(f"\n[Resolved Edits Table]:")
    print(f"  {'ID':<10} {'Source':<14} {'Original':<12} {'Replacement':<14} {'Category'}")
    print("  " + "-" * 65)
    for e in hybrid_result["resolved_edits"]:
        print(f"  {e['edit_id']:<10} {e['source']:<14} {e['original']:<12} {e['replacement']:<14} {e['category']}")

    print(f"\n[Unified Diff View]:")
    diff_str = ""
    for d in hybrid_result["diff_chunks"]:
        if d["type"] == "removed":
            diff_str += f"[-{d['text']}-]"
        elif d["type"] == "added":
            diff_str += f"[+{d['text']}+]"
        else:
            diff_str += d["text"]
    print(f"  {diff_str}")

    print("\n[Module 4 Execution Completed Successfully!]")

