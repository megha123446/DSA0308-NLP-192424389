"""
Module 1: Text Input & Preprocessing
Provides tokenization, sentence boundary detection, exact character offset tracking,
Part-of-Speech (POS) tagging, lemmatization, and linguistic feature extraction.
"""

import re
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass, asdict


# Common closed-class lexicons for high-precision POS tagging
DETERMINERS = {"a", "an", "the", "this", "that", "these", "those", "each", "every", "some", "any", "no"}
PRONOUNS_SUBJ = {"i", "you", "he", "she", "it", "we", "they", "who"}
PRONOUNS_OBJ = {"me", "him", "her", "us", "them", "whom"}
PRONOUNS_POSS = {"my", "your", "his", "her", "its", "our", "their", "mine", "yours", "hers", "ours", "theirs"}
PREPOSITIONS = {
    "about", "above", "across", "after", "against", "along", "among", "around", "at", "before",
    "behind", "below", "beneath", "beside", "between", "beyond", "by", "down", "during", "except",
    "for", "from", "in", "inside", "into", "near", "of", "off", "on", "onto", "out", "outside",
    "over", "past", "since", "through", "throughout", "to", "toward", "under", "until", "up", "upon",
    "with", "within", "without"
}
CONJUNCTIONS_COORD = {"and", "but", "or", "nor", "for", "yet", "so"}
CONJUNCTIONS_SUBORD = {"although", "because", "since", "unless", "while", "whereas", "if", "whether"}
MODAL_VERBS = {"can", "could", "may", "might", "shall", "should", "will", "would", "must"}
AUX_BE = {"am", "is", "are", "was", "were", "be", "being", "been"}
AUX_HAVE = {"have", "has", "had", "having"}
AUX_DO = {"do", "does", "did", "doing", "done"}

IRREGULAR_LEMMAS = {
    "went": ("go", "VBD"),
    "gone": ("go", "VBN"),
    "going": ("go", "VBG"),
    "goes": ("go", "VBZ"),
    "ran": ("run", "VBD"),
    "running": ("run", "VBG"),
    "runs": ("run", "VBZ"),
    "ate": ("eat", "VBD"),
    "eaten": ("eat", "VBN"),
    "eating": ("eat", "VBG"),
    "eats": ("eat", "VBZ"),
    "saw": ("see", "VBD"),
    "seen": ("see", "VBN"),
    "wrote": ("write", "VBD"),
    "written": ("write", "VBN"),
    "writing": ("write", "VBG"),
    "writes": ("write", "VBZ"),
    "took": ("take", "VBD"),
    "taken": ("take", "VBN"),
    "is": ("be", "VBZ"),
    "are": ("be", "VBP"),
    "was": ("be", "VBD"),
    "were": ("be", "VBD"),
    "has": ("have", "VBZ"),
    "had": ("have", "VBD"),
    "does": ("do", "VBZ"),
    "did": ("do", "VBD"),
    "better": ("good", "JJR"),
    "best": ("good", "JJS"),
    "worse": ("bad", "JJR"),
    "worst": ("bad", "JJS"),
    "children": ("child", "NNS"),
    "men": ("man", "NNS"),
    "women": ("woman", "NNS"),
    "feet": ("foot", "NNS"),
    "teeth": ("tooth", "NNS"),
    "mice": ("mouse", "NNS"),
    "people": ("person", "NNS"),
}


@dataclass
class Token:
    index: int
    text: str
    normalized: str
    lemma: str
    pos: str           # e.g., NOUN, VERB, ADJ, ADV, DET, PRON, ADP, CONJ, PRT, NUM, PUNCT
    tag: str           # Penn Treebank tag e.g. NN, NNS, VB, VBZ, VBD, VBG, JJ, RB, DT
    start: int         # character start offset in document
    end: int           # character end offset in document
    is_punct: bool
    is_stop: bool
    is_capitalized: bool
    syllables: int

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Sentence:
    index: int
    text: str
    start: int
    end: int
    token_count: int
    tokens: List[Dict[str, Any]]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TextPreprocessor:
    """Module 1: Preprocesses text into segmented sentences, tokens, POS tags, and metrics."""

    def __init__(self):
        self.stop_words = DETERMINERS | PREPOSITIONS | CONJUNCTIONS_COORD | AUX_BE | AUX_HAVE | AUX_DO

    def count_syllables(self, word: str) -> int:
        """Heuristic syllable counter for readability metrics."""
        word = word.lower().strip()
        if not word or not word.isalpha():
            return 1
        if len(word) <= 3:
            return 1
        word = re.sub(r'(?:[^laeiouy]|ed|es|e)$', '', word)
        word = re.sub(r'^y', '', word)
        matches = re.findall(r'[aeiouy]{1,2}', word)
        return max(1, len(matches))

    def detect_pos_and_lemma(self, token_str: str, prev_token: str = "", next_token: str = "") -> Tuple[str, str, str]:
        """
        Determines (Universal POS, Penn Treebank Tag, Lemma)
        using lexical lookup and morphological rules.
        """
        lower = token_str.lower()

        # Punctuation check
        if re.match(r'^[^\w\s]+$', token_str):
            return "PUNCT", token_str, token_str

        # Numbers
        if re.match(r'^\d+(\.\d+)?$', token_str):
            return "NUM", "CD", token_str

        # Irregular dictionary lookup
        if lower in IRREGULAR_LEMMAS:
            lemma, tag = IRREGULAR_LEMMAS[lower]
            pos = "VERB" if tag.startswith("V") else ("NOUN" if tag.startswith("N") else "ADJ")
            return pos, tag, lemma

        # Closed class checks
        if lower in DETERMINERS:
            return "DET", "DT", lower
        if lower in PRONOUNS_SUBJ:
            return "PRON", "PRP", lower
        if lower in PRONOUNS_OBJ:
            return "PRON", "PRP", lower
        if lower in PRONOUNS_POSS:
            return "PRON", "PRP$", lower
        if lower in PREPOSITIONS:
            return "ADP", "IN", lower
        if lower in CONJUNCTIONS_COORD:
            return "CONJ", "CC", lower
        if lower in CONJUNCTIONS_SUBORD:
            return "CONJ", "IN", lower
        if lower in MODAL_VERBS:
            return "VERB", "MD", lower
        if lower in AUX_BE:
            return "VERB", "VBZ" if lower in {"is"} else ("VBP" if lower in {"am", "are"} else "VBD"), "be"
        if lower in AUX_HAVE:
            return "VERB", "VBZ" if lower == "has" else ("VBP" if lower == "have" else "VBD"), "have"
        if lower in AUX_DO:
            return "VERB", "VBZ" if lower == "does" else ("VBP" if lower == "do" else "VBD"), "do"

        # Morphological suffixes
        if lower.endswith("ing"):
            lemma = re.sub(r'ing$', '', lower)
            if len(lemma) > 2 and lemma[-1] == lemma[-2]:
                lemma = lemma[:-1]
            return "VERB", "VBG", lemma
        if lower.endswith("ed"):
            lemma = re.sub(r'ed$', '', lower)
            return "VERB", "VBD", lemma
        if lower.endswith("ly"):
            lemma = re.sub(r'ly$', '', lower)
            return "ADV", "RB", lemma
        if lower.endswith(("tion", "ment", "ness", "ity", "ship", "ism", "ence", "ance")):
            return "NOUN", "NN", lower
        if lower.endswith(("able", "ible", "ous", "ful", "less", "ive", "al", "ic")):
            return "ADJ", "JJ", lower
        if lower.endswith("es") and len(lower) > 3:
            return "NOUN", "NNS", lower[:-2]
        if lower.endswith("s") and not lower.endswith("ss") and len(lower) > 2:
            # Could be plural noun or 3rd person singular verb
            if prev_token.lower() in PRONOUNS_SUBJ - {"i", "we", "they"}:
                return "VERB", "VBZ", lower[:-1]
            return "NOUN", "NNS", lower[:-1]

        # Contextual heuristics
        if prev_token.lower() in DETERMINERS:
            return "NOUN", "NN", lower
        if prev_token.lower() in MODAL_VERBS or prev_token.lower() == "to":
            return "VERB", "VB", lower

        # Default fallback: Noun / Base
        return "NOUN", "NN", lower

    def process(self, text: str) -> Dict[str, Any]:
        """
        Executes Module 1 Preprocessing pipeline:
        1. Text Sanitization
        2. Sentence segmentation with offsets
        3. Tokenization with exact character spans
        4. POS Tagging & Lemmatization
        5. Corpus & Readability Metrics
        """
        if not text or not text.strip():
            return {
                "raw_text": text,
                "sentences": [],
                "tokens": [],
                "stats": {
                    "character_count": len(text),
                    "word_count": 0,
                    "sentence_count": 0,
                    "avg_sentence_length": 0.0,
                    "avg_word_length": 0.0,
                    "syllable_count": 0,
                    "lexical_diversity": 0.0,
                }
            }

        # Sentence Boundary Detection with regex keeping spans
        sentence_regex = re.compile(r'([A-Z0-9][^.!?]*[.!?]+|[^.!?]+$)', re.MULTILINE)
        raw_sentences = []
        for match in sentence_regex.finditer(text):
            sent_str = match.group().strip()
            if sent_str:
                raw_sentences.append((match.start(), match.end(), sent_str))

        if not raw_sentences:
            raw_sentences = [(0, len(text), text.strip())]

        all_tokens: List[Token] = []
        sentences_output: List[Sentence] = []
        token_global_idx = 0
        total_syllables = 0
        word_tokens_count = 0
        unique_lemmas = set()

        # Token pattern: words, contractions (don't, it's), or punctuation
        token_regex = re.compile(r"([A-Za-z0-9]+(?:'[A-Za-z0-9]+)?|[^\w\s])")

        for sent_idx, (s_start, s_end, s_text) in enumerate(raw_sentences):
            sent_tokens: List[Token] = []
            
            # Find tokens within the sentence slice
            for m in token_regex.finditer(text[s_start:s_end]):
                t_str = m.group()
                t_start = s_start + m.start()
                t_end = s_start + m.end()

                is_punct = bool(re.match(r'^[^\w\s]+$', t_str))
                is_cap = t_str[0].isupper() if t_str else False
                syllables = self.count_syllables(t_str) if not is_punct else 0
                if not is_punct and t_str.isalnum():
                    word_tokens_count += 1
                    total_syllables += syllables

                # Context tokens
                prev_str = sent_tokens[-1].text if sent_tokens else ""
                pos, tag, lemma = self.detect_pos_and_lemma(t_str, prev_token=prev_str)
                is_stop = t_str.lower() in self.stop_words
                unique_lemmas.add(lemma.lower())

                tok = Token(
                    index=token_global_idx,
                    text=t_str,
                    normalized=t_str.strip(),
                    lemma=lemma,
                    pos=pos,
                    tag=tag,
                    start=t_start,
                    end=t_end,
                    is_punct=is_punct,
                    is_stop=is_stop,
                    is_capitalized=is_cap,
                    syllables=syllables
                )
                sent_tokens.append(tok)
                all_tokens.append(tok)
                token_global_idx += 1

            sentences_output.append(Sentence(
                index=sent_idx,
                text=s_text,
                start=s_start,
                end=s_end,
                token_count=len(sent_tokens),
                tokens=[t.to_dict() for t in sent_tokens]
            ))

        total_words = word_tokens_count
        avg_sent_len = round(total_words / max(1, len(sentences_output)), 2)
        total_word_chars = sum(len(t.text) for t in all_tokens if not t.is_punct)
        avg_word_len = round(total_word_chars / max(1, total_words), 2)
        lex_div = round(len(unique_lemmas) / max(1, total_words), 3)

        return {
            "raw_text": text,
            "sentences": [s.to_dict() for s in sentences_output],
            "tokens": [t.to_dict() for t in all_tokens],
            "stats": {
                "character_count": len(text),
                "word_count": total_words,
                "sentence_count": len(sentences_output),
                "avg_sentence_length": avg_sent_len,
                "avg_word_length": avg_word_len,
                "syllable_count": total_syllables,
                "lexical_diversity": lex_div
            }
        }


if __name__ == "__main__":
    print("=" * 70)
    print(" MODULE 1: TEXT INPUT & PREPROCESSING (STANDALONE RUNNER)")
    print(" Penn Treebank POS Tagging, Tokenization, Lemmatization & Stats")
    print("=" * 70)
    
    sample_text = "She walk to library and bought an book. He was interested about learning."
    preprocessor = TextPreprocessor()
    result = preprocessor.process(sample_text)

    print(f"\n[Input Text]: {sample_text}")
    print(f"\n[Sentences Detected]: {len(result['sentences'])}")
    for s in result["sentences"]:
        print(f"  Sentence {s['index'] + 1} [{s['start']}:{s['end']}]: \"{s['text']}\" ({s['token_count']} tokens)")

    print(f"\n[Token Stream Sample (first 10 tokens)]:")
    print(f"  {'Index':<6} {'Token':<14} {'POS':<8} {'Lemma':<12} {'Span':<10} {'Syllables'}")
    print("  " + "-" * 58)
    for tok in result["tokens"][:10]:
        span_str = f"[{tok['start']}:{tok['end']}]"
        print(f"  {tok['index']:<6} {tok['text']:<14} {tok['pos']:<8} {tok['lemma']:<12} {span_str:<10} {tok['syllables']}")

    print(f"\n[Linguistic Statistics]:")
    for k, v in result["stats"].items():
        print(f"  * {k}: {v}")
    print("\n[Module 1 Execution Completed Successfully!]")


