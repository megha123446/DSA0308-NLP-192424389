"""
Intelligent System for Automatic Grammar Error Detection and Correction
Capstone Project Package
"""
__version__ = "1.0.0"
