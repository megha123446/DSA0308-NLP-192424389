"""
Core Pipeline Coordinator
Orchestrates Module 1, Module 2, Module 3, Module 4, and Metrics.
Provides single-call analysis for real-time WebSockets and REST APIs.
"""

import time
import sys
import os
from typing import Dict, Any

try:
    from .module1_preprocessing import TextPreprocessor
    from .module2_rule_engine import RuleBasedGrammarDetector
    from .module3_transformer import TransformerGrammarCorrector
    from .module4_hybrid_arbiter import HybridErrorResolver
    from .metrics import calculate_metrics
except (ImportError, ValueError):
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    from core.module1_preprocessing import TextPreprocessor
    from core.module2_rule_engine import RuleBasedGrammarDetector
    from core.module3_transformer import TransformerGrammarCorrector
    from core.module4_hybrid_arbiter import HybridErrorResolver
    from core.metrics import calculate_metrics



class GrammarSystemPipeline:
    """End-to-end multi-module pipeline orchestrator."""

    def __init__(self):
        self.preprocessor = TextPreprocessor()
        self.rule_detector = RuleBasedGrammarDetector()
        self.transformer_corrector = TransformerGrammarCorrector()
        self.hybrid_resolver = HybridErrorResolver()

    def analyze(self, text: str) -> Dict[str, Any]:
        """
        Executes the entire 4-module pipeline and records performance latencies.
        """
        t0 = time.perf_counter()

        # Module 1: Preprocessing
        m1_start = time.perf_counter()
        preprocessed = self.preprocessor.process(text)
        m1_lat = (time.perf_counter() - m1_start) * 1000.0

        # Module 2: Rule-Based Detection
        m2_start = time.perf_counter()
        rule_errors = self.rule_detector.detect(text, preprocessed)
        m2_lat = (time.perf_counter() - m2_start) * 1000.0

        # Module 3: Transformer-Based Correction
        m3_start = time.perf_counter()
        transformer_result = self.transformer_corrector.correct(text, preprocessed)
        m3_lat = (time.perf_counter() - m3_start) * 1000.0

        # Module 4: Hybrid Integration & Error Resolution
        m4_start = time.perf_counter()
        hybrid_result = self.hybrid_resolver.resolve(
            text=text,
            rule_errors=rule_errors,
            transformer_suggestions=transformer_result["suggestions"]
        )
        m4_lat = (time.perf_counter() - m4_start) * 1000.0

        total_lat = (time.perf_counter() - t0) * 1000.0

        latencies = {
            "module1_preproc": m1_lat,
            "module2_rules": m2_lat,
            "module3_transformer": m3_lat,
            "module4_hybrid": m4_lat,
            "total_pipeline": total_lat
        }

        # Calculate Analytics & Readability Metrics
        metrics = calculate_metrics(
            preprocessed_data=preprocessed,
            rule_errors=rule_errors,
            transformer_data=transformer_result,
            hybrid_data=hybrid_result,
            latencies=latencies
        )

        return {
            "input_text": text,
            "module1_preprocessing": preprocessed,
            "module2_rule_engine": {
                "violations_count": len(rule_errors),
                "violations": rule_errors
            },
            "module3_transformer": transformer_result,
            "module4_hybrid": hybrid_result,
            "metrics": metrics
        }


if __name__ == "__main__":
    print("=" * 70)
    print(" INTELLIGENT GRAMMAR SYSTEM: END-TO-END PIPELINE RUNNER")
    print(" Orchestrating Module 1, Module 2, Module 3 & Module 4")
    print("=" * 70)

    test_text = (
        "She walk to library and bought an unique book. "
        "The committee will discuss about the proposal, but they was unprepared."
    )
    print(f"\n[Input Text]:\n  \"{test_text}\"\n")

    p = GrammarSystemPipeline()
    res = p.analyze(test_text)

    print(f"[Module 1 Stats]:")
    print(f"  * Sentences: {res['module1_preprocessing']['stats']['sentence_count']}")
    print(f"  * Words:     {res['module1_preprocessing']['stats']['word_count']}")
    print(f"  * Syllables: {res['module1_preprocessing']['stats']['syllable_count']}")

    print(f"\n[Module 2 Rule Engine]:")
    print(f"  * Violations Count: {res['module2_rule_engine']['violations_count']}")
    for v in res['module2_rule_engine']['violations']:
        print(f"    - {v['rule_name']} on \"{v['original']}\" -> \"{v['replacement']}\"")

    print(f"\n[Module 3 Transformer Engine]:")
    print(f"  * Fluency Score: {res['module3_transformer']['fluency_score']} / 100")
    print(f"  * Perplexity:    {res['module3_transformer']['perplexity_estimate']}")
    print(f"  * Suggestions:   {len(res['module3_transformer']['suggestions'])}")
    for s in res['module3_transformer']['suggestions']:
        print(f"    - {s['type']} on \"{s['original']}\" -> \"{s['replacement']}\" ({int(s['confidence']*100)}%)")

    print(f"\n[Module 4 Hybrid Arbitrated Output]:")
    print(f"  * Corrected Text:\n    \"{res['module4_hybrid']['final_corrected_text']}\"")
    print(f"  * Total Edits: {len(res['module4_hybrid']['resolved_edits'])}")
    print(f"  * Rule Share:  {res['module4_hybrid']['metrics']['rule_contribution_pct']}%")
    print(f"  * Trf Share:   {res['module4_hybrid']['metrics']['transformer_contribution_pct']}%")

    print(f"\n[Dashboard Telemetry]:")
    print(f"  * Grammar Health Score: {res['metrics']['grammar_health_score']} / 100")
    print(f"  * Flesch Reading Ease:  {res['metrics']['readability']['flesch_reading_ease']}")
    print(f"  * Total Latency:        {res['metrics']['latencies_ms']['total_pipeline']} ms")

    print("\n[Pipeline Execution Completed Successfully!]")

