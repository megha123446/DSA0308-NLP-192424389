"""
Metrics and Telemetry Engine
Calculates Grammar Health Score, Readability Indices (Flesch Reading Ease, Flesch-Kincaid Grade Level, ARI),
Error Density, and Module Latency Profiles.
"""

from typing import Dict, Any, List


def calculate_metrics(
    preprocessed_data: Dict[str, Any],
    rule_errors: List[Dict[str, Any]],
    transformer_data: Dict[str, Any],
    hybrid_data: Dict[str, Any],
    latencies: Dict[str, float]
) -> Dict[str, Any]:
    """
    Computes real-time analytical scores and readability metrics.
    """
    stats = preprocessed_data.get("stats", {})
    words = max(1, stats.get("word_count", 1))
    sentences = max(1, stats.get("sentence_count", 1))
    syllables = max(1, stats.get("syllable_count", words))
    chars = stats.get("character_count", 0)

    # 1. Readability Indices
    # Flesch Reading Ease: 206.835 - 1.015*(words/sentences) - 84.6*(syllables/words)
    words_per_sentence = words / sentences
    syllables_per_word = syllables / words
    chars_per_word = chars / words

    flesch_reading_ease = 206.835 - (1.015 * words_per_sentence) - (84.6 * syllables_per_word)
    flesch_reading_ease = max(0.0, min(100.0, round(flesch_reading_ease, 1)))

    # Flesch-Kincaid Grade Level: 0.39*(words/sentences) + 11.8*(syllables/words) - 15.59
    fk_grade = (0.39 * words_per_sentence) + (11.8 * syllables_per_word) - 15.59
    fk_grade = max(1.0, min(18.0, round(fk_grade, 1)))

    # Automated Readability Index (ARI): 4.71*(chars/words) + 0.5*(words/sentences) - 21.43
    ari = (4.71 * chars_per_word) + (0.5 * words_per_sentence) - 21.43
    ari = max(1.0, min(18.0, round(ari, 1)))

    # 2. Grammar Health Score (0 - 100)
    # Deductions based on error counts and severity
    total_errors = len(hybrid_data.get("resolved_edits", []))
    deductions = 0.0
    for err in hybrid_data.get("resolved_edits", []):
        cat = err.get("category", "")
        if "Agreement" in cat or "Tense" in cat:
            deductions += 12.0
        elif "Article" in cat or "Confusable" in cat:
            deductions += 8.0
        elif "Fluency" in cat:
            deductions += 5.0
        else:
            deductions += 3.0

    # Normalize deductions by word volume
    normalized_penalty = (deductions / words) * 35.0
    grammar_health_score = max(15.0, min(100.0, round(100.0 - normalized_penalty, 1)))

    # 3. Error Density (Errors per 100 words)
    error_density = round((total_errors / words) * 100.0, 2)

    # 4. Error Category Breakdown for Charts
    category_counts = {}
    for err in hybrid_data.get("resolved_edits", []):
        c = err.get("category", "Other")
        category_counts[c] = category_counts.get(c, 0) + 1

    return {
        "grammar_health_score": grammar_health_score,
        "readability": {
            "flesch_reading_ease": flesch_reading_ease,
            "flesch_grade_level": fk_grade,
            "automated_readability_index": ari,
            "reading_difficulty": (
                "Very Easy" if flesch_reading_ease >= 80 else
                "Standard / Plain English" if flesch_reading_ease >= 60 else
                "Fairly Difficult" if flesch_reading_ease >= 40 else "Academic / Complex"
            )
        },
        "error_density_per_100_words": error_density,
        "total_errors_detected": total_errors,
        "category_distribution": category_counts,
        "latencies_ms": {k: round(v, 2) for k, v in latencies.items()}
    }


if __name__ == "__main__":
    print("=" * 70)
    print(" METRICS & TELEMETRY ENGINE (STANDALONE RUNNER)")
    print(" Readability Indices, Grammar Health Score & Error Density")
    print("=" * 70)

    sample_preprocessed = {
        "stats": {
            "word_count": 20,
            "sentence_count": 2,
            "syllable_count": 28,
            "character_count": 105
        }
    }
    sample_rule_errors = [{"category": "Subject-Verb Agreement"}]
    sample_trf = {"suggestions": [{"category": "Fluency"}]}
    sample_hybrid = {
        "resolved_edits": [
            {"category": "Subject-Verb Agreement", "severity": "high"},
            {"category": "Article Usage", "severity": "high"},
            {"category": "Fluency", "severity": "medium"}
        ]
    }
    sample_latencies = {
        "module1_preproc": 3.2,
        "module2_rules": 8.5,
        "module3_transformer": 12.1,
        "module4_hybrid": 4.0,
        "total_pipeline": 27.8
    }

    metrics = calculate_metrics(
        preprocessed_data=sample_preprocessed,
        rule_errors=sample_rule_errors,
        transformer_data=sample_trf,
        hybrid_data=sample_hybrid,
        latencies=sample_latencies
    )

    print(f"\n[Grammar Health Score]: {metrics['grammar_health_score']} / 100")
    print(f"[Error Density]:        {metrics['error_density_per_100_words']} errors per 100 words")
    print(f"\n[Readability Indices]:")
    print(f"  * Flesch Reading Ease:         {metrics['readability']['flesch_reading_ease']} ({metrics['readability']['reading_difficulty']})")
    print(f"  * Flesch-Kincaid Grade Level:  {metrics['readability']['flesch_grade_level']}")
    print(f"  * Automated Readability Index: {metrics['readability']['automated_readability_index']}")
    print(f"\n[Latency Breakdown (ms)]:")
    for mod, lat in metrics["latencies_ms"].items():
        print(f"  * {mod:<22}: {lat:>6.2f} ms")

    print("\n[Metrics Execution Completed Successfully!]")

