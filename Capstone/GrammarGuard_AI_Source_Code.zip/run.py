"""
Launcher Script for the Intelligent Grammar System
Starts the FastAPI / Uvicorn server and provides browser launch URL.
"""

import uvicorn
import webbrowser
import sys
import os

if __name__ == "__main__":
    print("=" * 70)
    print("  INTELLIGENT GRAMMAR ERROR DETECTION AND CORRECTION SYSTEM")
    print("  Capstone Project: Rule-Based & Transformer Hybrid Architecture")
    print("=" * 70)
    print("  Server launching on: http://127.0.0.1:8000")
    print("  WebSocket endpoint:  ws://127.0.0.1:8000/ws/grammar")
    print("  Interactive UI:     http://127.0.0.1:8000")
    print("=" * 70)

    # Run Uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=False, log_level="info")
