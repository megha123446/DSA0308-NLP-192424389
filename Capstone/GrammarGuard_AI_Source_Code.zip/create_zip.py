import os
import zipfile

SOURCE_DIR = r"C:\Users\YASWANTH K\.gemini\antigravity-ide\scratch\intelligent-grammar-system"
OUTPUT_ZIP = os.path.join(SOURCE_DIR, "GrammarGuard_AI_Source_Code.zip")

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".git", ".idea", ".vscode"}
EXCLUDE_EXTS = {".pyc", ".zip"}

def zip_source_code():
    print(f"Creating zip file at: {OUTPUT_ZIP}")
    file_count = 0
    
    with zipfile.ZipFile(OUTPUT_ZIP, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(SOURCE_DIR):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTS:
                    continue
                if file.endswith("GrammarGuard_AI_Source_Code.zip"):
                    continue
                    
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, SOURCE_DIR)
                
                zipf.write(full_path, rel_path)
                file_count += 1
                print(f"  + Added: {rel_path}")

    size_kb = round(os.path.getsize(OUTPUT_ZIP) / 1024, 1)
    print(f"\n[SUCCESS] Successfully packaged {file_count} files into '{OUTPUT_ZIP}' ({size_kb} KB)")

if __name__ == "__main__":
    zip_source_code()
